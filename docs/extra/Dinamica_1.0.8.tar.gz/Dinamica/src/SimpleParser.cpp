/**
   \file SimpleParser.cpp

   \brief Definição de um parser simples para strings.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include "SimpleParser.h"

namespace DFF {

namespace SimpleParser {

    bool Rule::operator==(const char& c) const { return contents == std::string(&c, 1); }

    bool Rule::operator==(const std::string& str) const { return contents == str; }

    bool Rule::operator!=(const char& c) const { return !(*this == c); }

    bool Rule::operator!=(const std::string& str) const { return !(*this == str); }

    Context::Context(const std::string& input)
        : m_stream(input)
    {
    }

    std::istringstream::pos_type Context::tell() { return m_stream.tellg(); }

    void Context::seek(std::istringstream::pos_type pos) { m_stream.seekg(pos); }

    bool Context::eof() const { return m_stream.eof(); }

    std::istringstream& Context::getStream() { return m_stream; }

    RuleChar::RuleChar(Context& ctx, RuleAction peekOnly /*= DEFAULT */)
    {
        auto pos = ctx.tell();

        char tmpChar = ctx.getStream().get();
        while (tmpChar == ' ')
            tmpChar = ctx.getStream().get();

        contents += tmpChar;
        if (peekOnly == RuleAction::LOOK_AHEAD)
            ctx.seek(pos);
    }

    RuleChar::RuleChar(Context& ctx, const char c, RuleAction peekOnly /*= DEFAULT */)
    {
        auto pos = ctx.tell();
        char tmpChar = ctx.getStream().get();
        while (tmpChar == ' ')
            tmpChar = ctx.getStream().get();

        contents += tmpChar;
        if (tmpChar != c) {
            if (peekOnly == RuleAction::LOOK_AHEAD) {
                ctx.seek(pos);
                return;
            } else
                throwException_(std::runtime_error, "Expected '" << c << "', got '" << tmpChar << "'");
        }

        if (peekOnly == RuleAction::LOOK_AHEAD)
            ctx.seek(pos);
    }

    RuleWord::RuleWord(Context& ctx, RuleAction peekOnly /*= DEFAULT */)
    {
        auto pos = ctx.tell();

        ctx.getStream() >> contents;
        if (peekOnly == RuleAction::LOOK_AHEAD)
            ctx.seek(pos);
    }

    RuleWord::RuleWord(Context& ctx, const char c, RuleAction peekOnly /*= DEFAULT */)
    {
        std::istringstream& str = ctx.getStream();
        auto pos = ctx.tell();

        // Ignora espaço inicial
        char tmpChar = str.get();
        while (tmpChar == ' ')
            tmpChar = str.get();

        while (tmpChar != ' ' && tmpChar != c && !str.eof()) {
            contents += tmpChar;
            tmpChar = str.get();
        }

        if (peekOnly == RuleAction::LOOK_AHEAD)
            ctx.seek(pos);
    }

    RuleQuotedWord::RuleQuotedWord(Context& ctx, RuleAction peekOnly /*= DEFAULT */)
    {
        std::istringstream& str = ctx.getStream();
        auto pos = ctx.tell();

        char tmpChar = str.get();
        while (tmpChar == ' ' && !str.eof())
            tmpChar = str.get();

        // Lê as aspas duplas para começar
        if (tmpChar != '\"') {
            if (peekOnly == RuleAction::LOOK_AHEAD) {
                ctx.seek(pos);
                return;
            } else
                throwException_(std::runtime_error, "Expected '\"', got '" << tmpChar << "'");
        }

        // Lê o resto da string.
        while (!str.eof()) {
            tmpChar = str.get();
            if (tmpChar == '\n' || tmpChar == '\r' || tmpChar == '\"')
                break;

            contents += tmpChar;
        }

        if (peekOnly == RuleAction::LOOK_AHEAD)
            ctx.seek(pos);
    }

} // namespace SimpleParser

} // namespace DFF
