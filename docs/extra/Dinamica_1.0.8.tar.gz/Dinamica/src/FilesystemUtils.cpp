/**
   \file FilesystemUtils.cpp

   \brief Implementação de utilitários para manipulação de arquivos.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira

   \author Bruno Morais Ferreira

   \author Francisco de Paula Dias Neto

   \author Romulo Fernandes Machado
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <streambuf>
#include <string>

#ifdef _DFF_ON_WINDOWS_
#include <direct.h>
#include <shellapi.h>

#include "Shlwapi.h"
#else
#include <unistd.h>
#endif

#include "Atomic.h"
#include "ExceptionUtils.h"
#include "FilesystemUtils.h"
#include "Registry.h"
#include "StringUtils.h"

namespace fs = std::filesystem;

namespace DFF {

std::string FilesystemUtils::getFilenameExtension(const fs::path& filename) { return filename.extension().u8string(); }

fs::path FilesystemUtils::changeFilenameExtension(const fs::path& filename, const std::string& extension)
{
    // A extensão será alterada apenas na cópia do nome do arquivo.

    fs::path filename2 = filename;
    filename2.replace_extension(fs::u8path(extension));

    return filename2;
}

void FilesystemUtils::readFile(std::string& output, const fs::path& filename)
{
    std::ifstream input(filename);

    if (input.fail()) {
        throwException_(std::runtime_error, "Unable to read file \"" << genericString(filename) << "\".");
    }

    // Faz a leitura do arquivo e coloca o seu conteúdo na string dada.
    std::istreambuf_iterator<char> start(input), end;
    output.assign(start, end);
}

void FilesystemUtils::writeFile(std::istream& input, const fs::path& filename)
{
    const std::istream::pos_type inputPosition = input.tellg();
    try {
        std::string streamContent;
        streamContent.assign(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());

        input.seekg(inputPosition);
        writeFile(streamContent, filename);

    } catch (...) {

        input.seekg(inputPosition);
        throw;
    }
}

void FilesystemUtils::writeFile(const std::string& input, const fs::path& filename)
{
    std::ofstream outputFile(filename, std::ios_base::out | std::ios_base::binary);

    if (!outputFile.is_open())
        throwException_(std::runtime_error, "Failed to open filename \"" << genericString(
                                                filename) << "\" for writing. Please check your permissions.");

    try {
        outputFile.write(input.c_str(), input.length());
        outputFile.close();
    } catch (const std::exception& e) {
        throwException_(std::runtime_error, "Failed to manipulate the file \""
                                                << genericString(filename)
                                                << "\". Please check your permissions. Error details: " << e.what());
    }
}

fs::path FilesystemUtils::getRelativeFilename(const fs::path& filename) { return fs::relative(filename); }

fs::path FilesystemUtils::getRelativeFilename(const fs::path& directory, const fs::path& filename)
{
    return fs::relative(filename, directory);
}

fs::path FilesystemUtils::getCompleteFilename(const fs::path& directory, const fs::path& filename)
{
    if (!directory.is_absolute()) {
        throwException_(std::runtime_error, "The directory \"" << genericString(directory) << "\" is not complete.");
    }

    if (filename.is_absolute()) {
        throwException_(std::runtime_error, "The filename \"" << genericString(filename) << "\" is already complete.");
    }

    fs::path completeFilename;
    try {
        completeFilename = (directory / filename).lexically_normal();

    } catch (std::exception& /* e */) {
        throwException_(std::runtime_error,
            "The filename \"" << genericString(directory) << "/" << genericString(filename) << "\" is not valid.");
    }

    return completeFilename;
}

fs::path FilesystemUtils::generateFilename(
    const std::string& prefix, int suffixDigits, int suffix, const std::string& extension)
{
    std::string field;
    StringUtils::valueToField(field, suffix, suffixDigits);

    return fs::u8path(prefix + field + extension);
}

bool FilesystemUtils::canReadFilename(const fs::path& filename)
{
    // (pending) O código não é adequado pois abre o arquivo para leitura.

    std::fstream stream(filename, std::ios::in);
    return !stream.fail();
}

bool FilesystemUtils::canWriteFilename(const fs::path& filename)
{
    if (filenameExists(filename)) {
        // (pending) O código não é adequado pois abre o arquivo para escrita.

        std::fstream stream(filename, std::ios::out | std::ios::app);
        return !stream.fail();
    }

    return true;
}

bool FilesystemUtils::filenameExists(const fs::path& filename)
{
    // Contorna exceção disparada quando o status do arquivo não pode ser determinado.

    try {
        return fs::exists(filename);

    } catch (fs::filesystem_error& /* e */) {
        return false;
    }
}

fs::path FilesystemUtils::createTemporaryFile(const std::string& extension)
{
    const fs::path newFilePath = generateTemporaryFilename(extension);
    try {
        // Cria o arquivo desejado e o fecha em seguida para permitir que ele possa ser utilizado. Como as funções de
        // ostream não disparam exceção, é necessário verificar as flags de "qualidade".
        std::ofstream newFile(newFilePath);
        if (newFile.good())
            newFile.close();

        if (!newFile.good()) {
            throwException_(
                std::runtime_error, "Failed to create temporary file \"" << genericString(newFilePath) << "\".");
        }

    } catch (fs::filesystem_error& e) {
        throwException_(std::runtime_error, "Failed to create temporary file: " << e.what());
    }

    return newFilePath;
}

fs::path FilesystemUtils::generateTemporaryFilename(const std::string& extension)
{
#ifdef _DFF_ON_WINDOWS_
    std::wstring tempDir = StringUtils::fromUTF8(RegistryManager::Instance().getAutoProperty(REG_TEMPORARY_DIRECTORY_KEY));
    
    wchar_t tempFilenameBuffer[ 4096 ] = { 0 };
    if (::GetTempFileNameW(tempDir.c_str(), L"EGOTmp_", 0, tempFilenameBuffer) == 0) {
        DWORD errorCode = GetLastError();
        LPVOID errorMessageBuffer = 0;
        std::string errorMessage;
        if (errorCode != 0 && ::FormatMessage(
            FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL,
                errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&errorMessageBuffer, 0, NULL) != 0) {
            errorMessage = std::string((LPCTSTR)errorMessageBuffer);

            LocalFree(errorMessageBuffer);
         }
   
        if (!errorMessage.empty())
            throwException_(std::runtime_error, "Failed to get temporary file: " << errorMessage);
        else
            throwException_(std::runtime_error, "Failed to get temporary file.");
    }
    
    // Assume que a extensão é formada apenas por caracteres ASCII.
    std::wstring extension2(extension.begin(), extension.end());
    
    return fs::path(std::wstring(tempFilenameBuffer) + extension2);

#else
    std::string tempDir = RegistryManager::Instance().getAutoProperty(REG_TEMPORARY_DIRECTORY_KEY);
    std::string tempFilenameBlueprint = tempDir + "/dinamica-ego-r-XXXXXX";
    
    char* tempFilenameBuffer = strdup(tempFilenameBlueprint.c_str());
    const int tempFileDescriptor = mkstemp(tempFilenameBuffer);
    if (tempFileDescriptor == -1) {
        if (int errorCode = errno; errorCode != 0)
            throwException_(std::runtime_error, "Failed to get temporary file: " << strerror(errorCode));
        else
            throwException_(std::runtime_error, "Failed to get temporary file.");
    }
        
    std::string tempFilename(tempFilenameBuffer);
    free(tempFilenameBuffer);
    close(tempFileDescriptor);
    
    fs::path tempFilename2 = fs::u8path(tempFilename);
    tempFilename2.replace_extension(fs::path(extension));
    
    return tempFilename2;
#endif
}

std::string FilesystemUtils::getCompleteTemporaryPath(const std::string& baseName)
{
    const fs::path tempDirectory = fs::u8path(RegistryManager::Instance().getAutoProperty(REG_TEMPORARY_DIRECTORY_KEY));

    return genericString(tempDirectory / fs::u8path(baseName));
}

void FilesystemUtils::removeFileOrFolder(const fs::path& filename)
{
    try {
        fs::remove_all(filename);

    } catch (fs::filesystem_error& e) {
        throwException_(std::runtime_error, "Failed to remove \"" << genericString(filename) << "\": " << e.what());
    }
}

void FilesystemUtils::removeFileOrFolderIfPossible(const fs::path& filename)
{
    try {
        removeFileOrFolder(filename);

    } catch (std::exception& e) {
    }
}

std::string FilesystemUtils::getFancyFilenameString(const fs::path& workdir, const fs::path& filename)
{
    // Constrói a representação fantasia do nome de arquivo relativo do diretório de trabalho dado.

    std::string fancyInput;
    if (workdir.empty() || filename.has_root_path())
        fancyInput = genericString(filename);
    else if (filename.empty())
        fancyInput = genericString(workdir);
    else
        fancyInput = "[" + genericString(workdir) + "]/" + genericString(filename);

    return fancyInput;
}

std::string FilesystemUtils::string(const fs::path& path) { return path.u8string(); }

std::string FilesystemUtils::genericString(const fs::path& path) { return path.generic_u8string(); }

FileHandle::FileHandle(const fs::path& filename, const FILE_STRING& mode)
    : m_handle(0)
    , m_isOpen(false)
    , m_filename(filename)
{
#ifdef _DFF_ON_WINDOWS_
    m_handle = ::_wfopen(filename.wstring().c_str(), mode.c_str());
#else
    m_handle = ::fopen(FilesystemUtils::genericString(filename).c_str(), mode.c_str());
#endif

    m_isOpen = m_handle != 0;
}

FileHandle::~FileHandle() { close(true); }

long FileHandle::tellg() const { return ftell(m_handle); }

int FileHandle::seek(long pos) { return fseek(m_handle, pos, SEEK_SET); }

int FileHandle::getChar() { return std::fgetc(m_handle); }

std::size_t FileHandle::read(char* result, size_t numBytes) { return fread(result, numBytes, 1, m_handle); }

std::size_t FileHandle::write(const char* data, size_t numBytes) { return fwrite(data, numBytes, 1, m_handle); }

void FileHandle::close(bool noExcept)
{
    if (m_isOpen) {
        if (fclose(m_handle) != 0 && !noExcept) {
            throwException_(std::runtime_error,
                "Failed to close filename \"" << FilesystemUtils::genericString(m_filename) << "\"");
        }

        m_filename = fs::path();
        m_isOpen = false;
        m_handle = 0;
    }
}

int FileHandle::flush() { return fflush(m_handle); }

} // namespace DFF
