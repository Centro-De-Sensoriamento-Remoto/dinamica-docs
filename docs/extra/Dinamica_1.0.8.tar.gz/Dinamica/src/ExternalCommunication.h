/**
   \file ExternalCommunication.h

   \brief Utilitário para comunicação com aplicações externas.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#ifndef _DINAMICA_EXTERNA_COMMUNICATION_H_
#define _DINAMICA_EXTERNA_COMMUNICATION_H_

#include "Config.h"

#include <array>
#include <filesystem>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "Cancellable.h"
#include "FileMessageQueue.h"
#include "FileTaggedMessageQueue.h"

#define SHARED_QUEUE_SERVER_SUFFIX "_serverQueue"
#define SHARED_QUEUE_CLIENT_SUFFIX "_clientQueue"
#define QUEUE_MAX_MESSAGES 1024
#define MAX_FILENAME_PATH_SIZE 1024

namespace fs = std::filesystem;

namespace DFF {

/**
   \brief Tipos básicos de mensagem trocadas em conexões externas.
*/
enum class ExternalMessageTypes {

    /**
       \brief Um único número é enviado no próprio corpo da mensagem.
    */
    NUMBER = 0,

    /**
       \brief Uma lista de números é passada como conteúdo de um arquivo.
    */
    NUMBER_LIST,

    /**
       \brief Uma tabela (números) é passada como conteúdo de um arquivo.
    */
    LOOKUP_TABLE,

    /**
       \brief Uma string é passada no campo da mensagem.
    */
    STRING,

    /**
       \brief Uma mensagem de erro é passada no campo da mensagem.
    */
    ERROR_DESCRIPTION,

    /**
       \brief Uma tabela é passada como conteúdo de um arquivo (CSV).
    */
    TABLE,

    /**
       \brief Mensagens customizadas devem ser passadas com identificador maior que esse número.
    */
    MAX_MESSAGE_TYPES
};

/**
   \brief Gerencia comunicação com aplicações externas.
*/
class DFF_PUBLIC ExternalCommunication {
public:
    /**
       \brief Mensagem trocada entre processos.

       No caso da integração com o R (ou outras ferramentas), os arquivos que definem as mensagens nos outros projetos
       devem ter o mesmo formato de mensagem do Dinamica.
    */
    struct Message {

        /**
           \brief Indentificador do conteúdo / propósito da mensagem.
        */
        uint32_t m_identifier;

        /**
           \brief Espaço para que seja gravado um número.
        */
        double m_number;

        /**
           \brief Espaço para que seja gravado uma string.  O tamanho máximo dessa string deve ser
           MAX_FILENAME_PATH_SIZE.
        */
        std::array<char, MAX_FILENAME_PATH_SIZE> m_string;

        /**
           \brief Constrói uma mensagem vazia.
        */
        Message()
            : m_identifier(0)
            , m_number(0)
        {
            m_string.fill(0);
        }

        /**
           \brief Constrói uma mensagem apenas com identificador.
        */
        explicit Message(uint32_t identifier)
            : m_identifier(identifier)
            , m_number(0)
        {
            m_string.fill(0);
        }

        /**
           \brief Constrói uma mensagem com identificador e um número.
        */
        explicit Message(uint32_t identifier, double number)
            : m_identifier(identifier)
            , m_number(number)
        {
            m_string.fill(0);
        }

        /**
           \brief Constrói uma mensagem com identificador e um nome de arquivo.
        */
        explicit Message(uint32_t identifier, const std::array<char, MAX_FILENAME_PATH_SIZE>& string)
            : m_identifier(identifier)
            , m_number(0)
            , m_string(string)
        {
        }

        /**
           \brief Constrói uma mensagem com identificador e um nome de arquivo.
        */
        explicit Message(uint32_t identifier, const std::string& string)
            : m_identifier(identifier)
            , m_number(0)
        {
            m_string.fill(0);
            for (std::size_t i = 0; i < string.length(); ++i)
                m_string[i] = string[i];
        }

        /**
           \brief Retorna a string armazenada na mensagem como std::string.
        */
        std::string getString() const { return std::string(m_string.data()); }
    };

    /**
       \brief Constrói uma instância de comunicação com aplicações externas.

       Essa sessão não troca dados até que seja inicializada ou conectada à uma outra sessão já existente.
     */
    ExternalCommunication();

    /**
       \brief Finaliza a sessão interrompendo quaisquer conexões existentes.
     */
    ~ExternalCommunication();

    /**
       \brief Inicializa a sessão para compartilhamento de informações com aplicações externas.  (DISPONÍVEL NO JAVA).

       \param sessionIdentifier Identificador da sessão a ser criada.

       \exception DFF::Exception Caso a sessão não possa ser criada.
     */
    void createSession(const std::string& sessionIdentifier);

    /**
       \brief Encerra a sessão de compartilhamento.  (DISPONÍVEL NO JAVA).
     */
    void destroy();

    /**
       \brief Conecta a uma sessão ativa para compartilhamento de informações com aplicações externas.

       \param sessionIdentifier Identificador único de sessão, esse identificador deve respeitar as normas de nome do
       C++ (impostas pelo boost).

       \exception DFF::Exception Caso a sessão não possa ser conectada.
     */
    void openSession(const std::string& sessionIdentifier);

    /**
       \brief Envia uma mensagem através da fila de mensagens.

       Caso a fila esteja cheia, bloqueia até que a mensagem possa ser enviada.

       \param message Mensagem a ser enviada.

       \param cancellationTest Função responsável por verificar o cancelamento da execução.
    */
    void sendMessage(const Message& message, const std::string& tag = std::string(),
        CancellationTest cancellationTest = createCancellationTest());

    /**
       \brief Recebe a primeira mensagem da fila.

       A mensagem recebida será removida da fila e não poderá ser recuperada novamente. Caso a fila esteja vazia,
       bloqueia até que uma mensagem seja recebida.

       \param cancellationTest Função responsável por verificar o cancelamento da execução.
    */
    Message receiveMessage(
        const std::string& tag = std::string(), CancellationTest cancellationTest = createCancellationTest());

    /**
       \brief Utilitário para remover uma sessão existente pelo nome.

       \param identifier Identificador da sessão a ser destruída.
    */
    static void destroySession(const std::string& identifier);

    /**
       \brief Retorna se uma sessão já existe.  (DISPONÍVEL NO JAVA).

       \param identifier Identificador da sessão a ser descoberta.
    */
    static bool sessionExists(const std::string& identifier);

    /**
       \brief Retorna o identificador usado.  (DISPONÍVEL NO JAVA).
    */
    inline const std::string& getIdentifier() const { return m_sessionIdentifier; }

    /**
       \brief Retorna o número máximo de mensagens que podem ser enviadas antes da fila ser travada.
    */
    std::size_t getMaxNumberOfMessages() const;

    /**
       \brief Grava uma lista de números no arquivo passado.

       \param numberCount Quantidade de números que devem ser lidos.

       \param getNumber Função responsável por retornar cada número a partir do índice pedido.

       \param filename Caminho válido para o arquivo onde os números serão gravados.
    */
    static void storeNumbersOnFilename(
        std::size_t numberCount, const std::function<double(std::size_t)>& getNumber, const fs::path& filename);

    /**
       \brief Recupera uma lista de números do arquivo passado.

       \param setNumber Função responsável por receber cada número da lista lida.

       \param filename Caminho válido para o arquivo onde os números estão gravados.
    */
    static void getNumbersFromFilename(const std::function<void(double)>& setNumber, const fs::path& filename);

private:
    /**
       \brief Indica se a sessão aberta foi construída ou apenas conectada à uma sessão já existente.
    */
    bool m_sessionCreated;

    /**
       \brief Identificador único da sessão. Esse identificador deve ter as mesmas restrições que nomes de variáveis em
       C++ (impostas pelo boost).
    */
    std::string m_sessionIdentifier;

    /**
       \brief Fila de mensagens para envio.
    */
    std::shared_ptr<FileMessageQueue> m_sendQueue;

    /**
       \brief Fila de mensagens (com tag) para envio.
    */
    std::shared_ptr<FileTaggedMessageQueue> m_tagSendQueue;

    /**
       \brief Fila de mensagens para recebimento.
    */
    std::shared_ptr<FileMessageQueue> m_receiveQueue;

    /**
       \brief Fila de mensagens (com tag) para recebimento.
    */
    std::shared_ptr<FileTaggedMessageQueue> m_tagReceiveQueue;
};

/**
   \brief Grava a representação do tipo de mensagem no stream dado.
*/
DFF_PUBLIC std::ostream& operator<<(std::ostream& os, ExternalMessageTypes type);

} // namespace DFF

#endif
