/**
   \file FilesystemLock.h

   \brief Definição de uma trava para acesso exclusivo à arquivos.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#ifndef _DFF_FILENAME_LOCK_H_
#define _DFF_FILENAME_LOCK_H_

#include "Config.h"

#include <filesystem>
#include <string>

#ifdef _DFF_ON_WINDOWS_
#define FILENAME_LOCK_SUFFIX L".lock"
#else
#define FILENAME_LOCK_SUFFIX ".lock"
#endif

namespace fs = std::filesystem;

namespace DFF {

/**
   \brief Trava para acesso exclusivo à um arquivo.

   A trava é obtida no construtor e liberada no destrutor.  Esse arquivo não poderá ser utilizado para leitura e
   escrita, ele apenas serve como uma trava no sistema de arquivos (como um mutex).
*/
class DFF_PUBLIC FilenameLock {
public:
    /**
       \brief Comportamento esperado ao tentar pegar a trava do arquivo e falhar.
    */
    enum class LockBehavior {

        /**
           \brief Uma espera ocupada será feita caso o não seja possível travar o arquivo (esse é o modo padrão).
        */
        WAIT_ON_BUSY,

        /**
           \brief Uma exceção será disparada no construtor caso não seja possível travar o arquivo.
        */
        THROW_ON_BUSY
    };

    /**
       \brief Obtém uma trava para o nome de arquivo passado.

       \param filename Nome de arquivo a ter o acesso exclusivo.

       \param lockBehavior Comportamento esperado ao tentar realizar a trava. \see LockBehavior

       \param preventSharing Flag indicando se o acesso ao arquivo deve ser exclusivo dessa instância da aplicação.
       Falso por padrão.

       \exception Exception Caso não seja possível obter uma trava para o arquivo.
    */
    FilenameLock(
        const fs::path& filename, LockBehavior lockBehavior = LockBehavior::WAIT_ON_BUSY, bool preventSharing = false);

    /**
       \brief Libera a trava para o nome de arquivo especificado no construtor.
    */
    ~FilenameLock();

    /**
       \brief Libera a trava para o nome de arquivo especificado no construtor.
    */
    void release() noexcept;

private:
    /**
       \brief Trava para o arquivo usada pelo sistema.
    */
#ifdef _DFF_ON_WINDOWS_
    HANDLE m_handle;
#else
    // Armazena o file descriptor do arquivo.
    int m_handle;
#endif
};

} // namespace DFF

#endif
