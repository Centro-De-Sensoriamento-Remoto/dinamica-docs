#include <chrono>
#include <cstdio>
#include <filesystem>
#include <sstream>

#include <Rcpp.h>

#include "ExceptionUtils.h"
#include "ExternalCommunication.h"
#include "FilesystemUtils.h"
#include "StringUtils.h"

namespace fs = std::filesystem;

namespace {

/**
   \brief Escreve a tabela passada pelo R em um arquivo CSV.

   Implementação da escrita (essa implementação pode disparar livremente uma vez que os erros serão capturados um nível
   acima).
*/
void writeTableToFileImpl(const Rcpp::DataFrame& table, DFF::FileHandle& writeFile, int64_t keyColumnsMaxIndex)
{
    const Rcpp::CharacterVector names(table.attr("names"));
    const auto namesCount = names.size();

    // Armazena as colunas da tabela.
    std::vector<Rcpp::List> tableColumns;

    for (auto i = 0; i < namesCount; ++i) {
        if (i > 0)
            writeFile.write(", ", 2);

        const std::string columnName(names[i]);
        writeFile.write(columnName.c_str(), columnName.length());

        if (i < keyColumnsMaxIndex && columnName.rfind("*") == std::string::npos) {
            writeFile.write("*", 1);
        }

        tableColumns.push_back(table[columnName.c_str()]);
    }

    writeFile.write("\n", 1);

    // Recupera o número de entradas da tabela através
    // do tamanho da primeira coluna.
    const auto rowsCount = tableColumns[0].size();

    // Escreve as linhas
    for (auto rowIndex = 0; rowIndex < rowsCount; ++rowIndex) {
        for (auto colIndex = 0; colIndex < namesCount; ++colIndex) {
            const Rcpp::List& column = tableColumns[colIndex];
            if (colIndex > 0)
                writeFile.write(", ", 2);

            const auto columnData(column[rowIndex]);
            if (Rcpp::is<std::string>(columnData)) {
                const std::string writeData(Rcpp::as<std::string>(columnData));
                writeFile.write("\"", 1);
                writeFile.write(writeData.c_str(), writeData.length());
                writeFile.write("\"", 1);
            } else if (Rcpp::is<double>(columnData)) {
                const std::string writeData(DFF::toString(Rcpp::as<double>(columnData)));

                writeFile.write(writeData.c_str(), writeData.length());
            } else if (Rcpp::is<int>(columnData)) {
                const std::string writeData(DFF::toString(Rcpp::as<int>(columnData)));

                writeFile.write(writeData.c_str(), writeData.length());
            } else if (Rcpp::is<bool>(columnData)) {
                const std::string writeData(DFF::toString(Rcpp::as<bool>(columnData)));

                writeFile.write(writeData.c_str(), writeData.length());
                writeFile.write("\"", 1);
                writeFile.write(writeData.c_str(), writeData.length());
                writeFile.write("\"", 1);
            } else {
                throwException_(std::runtime_error, "Only numeric types and string convertible "
                                                    "types are acceptable.");
            }
        }

        writeFile.write("\n", 1);
    }
}

/**
   \brief Escreve a tabela passada pelo R em um arquivo CSV.
   Dispara se não for possível escrever a tabela.
*/
void writeTableToFile(const Rcpp::DataFrame& table, const fs::path& filename, int64_t keyColumnsMaxIndex)
{

#ifdef _DFF_ON_WINDOWS_
    DFF::FileHandle writeFile(filename, L"w");
#else
    DFF::FileHandle writeFile(filename, "w");
#endif

    if (!writeFile.is_open()) {
        throwException_(std::runtime_error,
            "Failed to open \"" << DFF::FilesystemUtils::genericString(filename) << "\" for writing.");
    }

    try {
        // Configura a precisão correta.
        writeTableToFileImpl(table, writeFile, keyColumnsMaxIndex);

    } catch (...) {
        // Remove o arquivo uma vez que ele não será mais enviado e já foi aberto.
        writeFile.close();
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(filename);
        throw;
    }
}

} // namespace

// Gerencia a singleton da sessão
DFF::ExternalCommunication& Instance()
{
    static DFF::ExternalCommunication instance;

    return instance;
}

//[[Rcpp::export]]
SEXP openSession(SEXP identifier)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.openSession(Rcpp::as<std::string>(identifier));

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP createSession(SEXP identifier)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.createSession(Rcpp::as<std::string>(identifier));

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP destroySession(SEXP identifier)
{
    BEGIN_RCPP
    DFF::ExternalCommunication::destroySession(Rcpp::as<std::string>(identifier));

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNumber(SEXP number)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage(
        DFF::ExternalCommunication::Message((int)DFF::ExternalMessageTypes::NUMBER, Rcpp::as<double>(number)), "");

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNamedNumber(SEXP name, SEXP number)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage(
        DFF::ExternalCommunication::Message((int)DFF::ExternalMessageTypes::NUMBER, Rcpp::as<double>(number)),
        Rcpp::as<std::string>(name));

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP receiveNumber()
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage("");
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::NUMBER)
        throwException_(std::runtime_error, "Received message does not contain a number.");

    return Rcpp::wrap(message.m_number);
    END_RCPP
}

//[[Rcpp::export]]
SEXP receiveNamedNumber(SEXP name)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage(Rcpp::as<std::string>(name));
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::NUMBER)
        throwException_(std::runtime_error, "Received message does not contain a number.");

    return Rcpp::wrap(message.m_number);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNumberVector(SEXP numberVector)
{
    BEGIN_RCPP
    Rcpp::NumericVector list(numberVector);
    auto getNumber = [&](size_t index) -> double { return list[index]; };

    fs::path tmpFilename = DFF::FilesystemUtils::createTemporaryFile("");

    try {
        DFF::ExternalCommunication::storeNumbersOnFilename(list.size(), getNumber, tmpFilename);

        DFF::ExternalCommunication& communicationInstance = Instance();
        communicationInstance.sendMessage(
            DFF::ExternalCommunication::Message(
                (int)DFF::ExternalMessageTypes::NUMBER_LIST, DFF::FilesystemUtils::genericString(tmpFilename)),
            "");

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(tmpFilename);
        throw;
    }

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNamedNumberVector(SEXP name, SEXP numberVector)
{
    BEGIN_RCPP
    Rcpp::NumericVector list(numberVector);
    auto getNumber = [&](size_t index) -> double { return list[index]; };

    fs::path tmpFilename = DFF::FilesystemUtils::createTemporaryFile("");

    try {
        DFF::ExternalCommunication::storeNumbersOnFilename(list.size(), getNumber, tmpFilename);

        DFF::ExternalCommunication& communicationInstance = Instance();
        communicationInstance.sendMessage(
            DFF::ExternalCommunication::Message(
                (int)DFF::ExternalMessageTypes::NUMBER_LIST, DFF::FilesystemUtils::genericString(tmpFilename)),
            Rcpp::as<std::string>(name));

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(tmpFilename);
        throw;
    }

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP receiveNumberVector()
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage("");
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::NUMBER_LIST)
        throwException_(std::runtime_error, "Received message does not contain a number list.");

    std::vector<double> numbers;
    auto setNumber = [&](double number) { numbers.push_back(number); };

    DFF::ExternalCommunication::getNumbersFromFilename(setNumber, fs::u8path(message.getString()));
    DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));

    return Rcpp::wrap(numbers);
    END_RCPP
}

//[[Rcpp::export]]
SEXP receiveNamedNumberVector(SEXP name)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage(Rcpp::as<std::string>(name));
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::NUMBER_LIST)
        throwException_(std::runtime_error, "Received message does not contain a number list.");

    std::vector<double> numbers;
    auto setNumber = [&](double number) { numbers.push_back(number); };

    DFF::ExternalCommunication::getNumbersFromFilename(setNumber, fs::u8path(message.getString()));
    DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));

    return Rcpp::wrap(numbers);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendLookupTable(SEXP keysVector, SEXP valuesVector)
{
    BEGIN_RCPP
    Rcpp::NumericVector keys(keysVector);
    Rcpp::NumericVector values(valuesVector);

    if (keys.size() != values.size())
        throwException_(std::runtime_error, "Keys and values vector must have the same size.");

    const size_t numbersCount = keys.size() + values.size();
    auto getNumber = [&](size_t index) -> double {
        if (index < (size_t)keys.size())
            return keys[index];
        else
            return values[index - keys.size()];
    };

    fs::path tmpFilename = DFF::FilesystemUtils::createTemporaryFile("");

    try {
        DFF::ExternalCommunication::storeNumbersOnFilename(numbersCount, getNumber, tmpFilename);

        DFF::ExternalCommunication& communicationInstance = Instance();
        communicationInstance.sendMessage(
            DFF::ExternalCommunication::Message(
                (int)DFF::ExternalMessageTypes::LOOKUP_TABLE, DFF::FilesystemUtils::genericString(tmpFilename)),
            "");

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(tmpFilename);
        throw;
    }

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNamedLookupTable(SEXP name, SEXP keysVector, SEXP valuesVector)
{
    BEGIN_RCPP
    Rcpp::NumericVector keys(keysVector);
    Rcpp::NumericVector values(valuesVector);

    if (keys.size() != values.size())
        throwException_(std::runtime_error, "Keys and values vector must have the same size.");

    const size_t numbersCount = keys.size() + values.size();
    auto getNumber = [&](size_t index) -> double {
        if (index < (size_t)keys.size())
            return keys[index];
        else
            return values[index - keys.size()];
    };

    fs::path tmpFilename = DFF::FilesystemUtils::createTemporaryFile("");

    try {
        DFF::ExternalCommunication::storeNumbersOnFilename(numbersCount, getNumber, tmpFilename);

        DFF::ExternalCommunication& communicationInstance = Instance();
        communicationInstance.sendMessage(
            DFF::ExternalCommunication::Message(
                (int)DFF::ExternalMessageTypes::LOOKUP_TABLE, DFF::FilesystemUtils::genericString(tmpFilename)),
            Rcpp::as<std::string>(name));

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(tmpFilename);
        throw;
    }

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
Rcpp::DataFrame receiveLookupTable()
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage("");
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::LOOKUP_TABLE)
        throwException_(std::runtime_error, "Received message does not contain a lookup table.");

    std::vector<double> numbers;
    auto setNumber = [&](double number) { numbers.push_back(number); };

    DFF::ExternalCommunication::getNumbersFromFilename(setNumber, fs::u8path(message.getString()));
    DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));

    Rcpp::NumericVector keys;
    Rcpp::NumericVector values;

    size_t numberOfKeys = numbers.size() / 2;
    for (size_t i = 0; i < numberOfKeys; ++i) {
        const double key = numbers[i];
        const double value = numbers[i + numberOfKeys];

        keys.push_back(key);
        values.push_back(value);
    }

    return Rcpp::DataFrame::create(Rcpp::Named("Keys") = keys, Rcpp::Named("Values") = values);
    END_RCPP
}

//[[Rcpp::export]]
Rcpp::DataFrame receiveNamedLookupTable(SEXP name)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage(Rcpp::as<std::string>(name));
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::LOOKUP_TABLE)
        throwException_(std::runtime_error, "Received message does not contain a lookup table.");

    std::vector<double> numbers;
    auto setNumber = [&](double number) { numbers.push_back(number); };

    DFF::ExternalCommunication::getNumbersFromFilename(setNumber, fs::u8path(message.getString()));
    DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));

    Rcpp::NumericVector keys;
    Rcpp::NumericVector values;

    size_t numberOfKeys = numbers.size() / 2;
    for (size_t i = 0; i < numberOfKeys; ++i) {
        const double key = numbers[i];
        const double value = numbers[i + numberOfKeys];

        keys.push_back(key);
        values.push_back(value);
    }

    return Rcpp::DataFrame::create(Rcpp::Named("Keys") = keys, Rcpp::Named("Values") = values);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendString(SEXP str)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage(
        DFF::ExternalCommunication::Message((int)DFF::ExternalMessageTypes::STRING, Rcpp::as<std::string>(str)), "");

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNamedString(SEXP name, SEXP str)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage(
        DFF::ExternalCommunication::Message((int)DFF::ExternalMessageTypes::STRING, Rcpp::as<std::string>(str)),
        Rcpp::as<std::string>(name));

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP receiveString()
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage("");
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::STRING)
        throwException_(std::runtime_error, "Received message does not contain a string.");

    return Rcpp::wrap(DFF::StringUtils::toR(message.getString()));
    END_RCPP
}

//[[Rcpp::export]]
SEXP receiveNamedString(SEXP name)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage(Rcpp::as<std::string>(name));
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::STRING)
        throwException_(std::runtime_error, "Received message does not contain a string.");

    return Rcpp::wrap(DFF::StringUtils::toR(message.getString()));
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendErrorString(SEXP str)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage(
        DFF::ExternalCommunication::Message(
            (int)DFF::ExternalMessageTypes::ERROR_DESCRIPTION, Rcpp::as<std::string>(str)),
        "");

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendTable(SEXP argTable, int64_t numberOfKeyColumns = -1)
{
    BEGIN_RCPP
    fs::path tmpFilename = DFF::FilesystemUtils::createTemporaryFile(".csv");

    const Rcpp::DataFrame table(argTable);
    writeTableToFile(table, tmpFilename, numberOfKeyColumns);

    try {
        DFF::ExternalCommunication& communicationInstance = Instance();
        communicationInstance.sendMessage(DFF::ExternalCommunication::Message((int)DFF::ExternalMessageTypes::TABLE,
                                              DFF::FilesystemUtils::genericString(tmpFilename)),
            "");

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(tmpFilename);
        throw;
    }

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
SEXP sendNamedTable(SEXP name, SEXP argTable, int64_t numberOfKeyColumns = -1)
{
    BEGIN_RCPP
    fs::path tmpFilename = DFF::FilesystemUtils::createTemporaryFile(".csv");

    const Rcpp::DataFrame table(argTable);
    writeTableToFile(table, tmpFilename, numberOfKeyColumns);

    try {
        DFF::ExternalCommunication& communicationInstance = Instance();
        communicationInstance.sendMessage(DFF::ExternalCommunication::Message((int)DFF::ExternalMessageTypes::TABLE,
                                              DFF::FilesystemUtils::genericString(tmpFilename)),
            Rcpp::as<std::string>(name));

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(tmpFilename);
        throw;
    }

    return Rcpp::wrap(0);
    END_RCPP
}

//[[Rcpp::export]]
Rcpp::DataFrame receiveTable()
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage("");
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::TABLE)
        throwException_(std::runtime_error, "Received message does not contain a table.");

    // Transform filename to UTF8 string.
    std::string filename = DFF::StringUtils::toR(message.getString());

    Rcpp::Language readCSV("read.csv", filename, Rcpp::Named("header", true), Rcpp::Named("sep", ','),
        Rcpp::Named("dec", '.'), Rcpp::Named("fill", true), Rcpp::Named("stringsAsFactors", false),
        Rcpp::Named("strip.white", true));

    try {
        const SEXP resultTable = readCSV.eval();
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));

        return resultTable;

    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));
        throw;
    }
    END_RCPP
}

//[[Rcpp::export]]
Rcpp::DataFrame receiveNamedTable(SEXP name)
{
    BEGIN_RCPP
    DFF::ExternalCommunication& communicationInstance = Instance();

    auto message = communicationInstance.receiveMessage(Rcpp::as<std::string>(name));
    if (message.m_identifier != (int)DFF::ExternalMessageTypes::TABLE)
        throwException_(std::runtime_error, "Received message does not contain a table.");

    // Transform filename to UTF8 string.
    std::string filename = DFF::StringUtils::toR(message.getString());

    Rcpp::Language readCSV("read.csv", filename, Rcpp::Named("header", true), Rcpp::Named("sep", ','),
        Rcpp::Named("dec", '.'), Rcpp::Named("fill", true), Rcpp::Named("stringsAsFactors", false),
        Rcpp::Named("strip.white", true));

    try {
        const SEXP resultTable = readCSV.eval();
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));

        return resultTable;
    } catch (...) {
        DFF::FilesystemUtils::removeFileOrFolderIfPossible(fs::u8path(message.getString()));
        throw;
    }
    END_RCPP
}
