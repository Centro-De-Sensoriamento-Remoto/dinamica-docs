/**
   \file ExceptionUtils.h

   \brief Definições úteis para o manuseio de exceções.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira
*/

#ifndef _DFF_EXCEPTION_UTILS_H_
#define _DFF_EXCEPTION_UTILS_H_

#include "Config.h"

#include <sstream>

namespace DFF {

/**
   \brief Lança uma exceção de tipo dado com a mensagem dada sem registrá-lo.

   A mensagem dada NÃO é registrada como uma mensagem de depuração no registro mantido pelo gerenciador de registros.

   Devido às regras de precedência, a mensagem dada pode ser construída usando ou o operador \c << (inserção em stream)
   ou o operador \c + (concatenação de strings) de forma transparente. O código a seguir ilustra:

   \code
   throwException_( DFF::Exception, "Invalid operand " << operand );

   throwException_( DFF::Exception, "Invalid operand " + toString( operand ) );
   \endcode

   \param EXCEPTION Tipo da exceção a ser lançada.

   \param MESSAGE Mensagem descrevendo a exceção a ser lançada.
*/
#define throwException_(EXCEPTION, MESSAGE)                                                                            \
    do {                                                                                                               \
        std::stringstream exceptionStream__;                                                                           \
        exceptionStream__ << MESSAGE;                                                                                  \
                                                                                                                       \
        EXCEPTION exception__(exceptionStream__.str());                                                                \
                                                                                                                       \
        throw exception__;                                                                                             \
                                                                                                                       \
    } while (false)

} // namespace DFF

#endif
