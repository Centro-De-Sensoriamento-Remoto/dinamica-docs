/**
   \file Atomic.h

   \brief Definições básicas de variáveis atômicas.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira

   \author Romulo Fernandes Machado
*/

#ifndef _DFF_ATOMIC_H_
#define _DFF_ATOMIC_H_

#include "Config.h"

#include <atomic>

namespace DFF {

/**
   \brief Definição básica de variáveis atômicas.

   \attention Pode ser usado apenas para os tipos inteiros representáveis usando 32 bits.
*/
template <typename ValueT> class Atomic;

template <> class Atomic<bool> {
public:
    /**
       \brief Constrói nova variável contendo false.
    */
    Atomic() noexcept
        : m_value(false)
    {
    }

    /**
       \brief Constrói nova variável contendo o valor dado.
    */
    Atomic(bool value) noexcept
        : m_value(value)
    {
    }

    /**
       \brief Construtor de cópia.
    */
    Atomic(const Atomic<bool>& atomic)
        : m_value(atomic)
    {
    }

    /**
       \brief Operador de atribuição.
    */
    Atomic<bool>& operator=(const Atomic<bool>& atomic)
    {
        if (this != &atomic)
            m_value = atomic.m_value.load();

        return *this;
    }

    /**
       \brief Retorna o valor da variável.
    */
    operator bool() const { return m_value.load(); }

    /**
       \brief Retorna o valor da variável.
    */
    bool load() const { return m_value.load(); }

    /**
       \brief Atualiza o valor da variável se o valor é igual ao valor de teste dado.

       É parcialmente equivalente a

       \code
           if ( variable == testValue )
             variable = updateValue;
       \endcode

       \param testValue Valor de teste da variável.

       \param updateValue Valor usado para atualizar o conteúdo da variável.

       \return True, caso o valor da variável tenha sido atualizado, e false, caso contrário.
    */
    bool testAndSet(bool testValue, bool updateValue)
    {
        return m_value.compare_exchange_strong(testValue, updateValue);
    }

    /**
       \brief Possivelmente, atualiza o valor da variável se o valor é igual ao valor de teste dado.

       É parcialmente equivalente a

       \code
           if ( _rand_ && variable == testValue )
             variable = updateValue;
       \endcode

       Ao contrário do testAndSet(), ela pode não atualizar o valor sempre, mas seu uso é recomendada em loops.

       \param testValue Valor de teste da variável.

       \param updateValue Valor usado para atualizar o conteúdo da variável.

       \return True, caso o valor da variável tenha sido atualizado, e false, caso contrário.
    */
    bool testAndPossiblySet(bool testValue, bool updateValue)
    {
        return m_value.compare_exchange_weak(testValue, updateValue);
    }

    /**
       \brief Altera o valor da variável e retorna o seu valor anterior.

       \param value Novo valor da variável.

       \return Valor anterior da variável.
    */
    bool swap(bool value) { return m_value.exchange(value); }

    /**
       \brief Operador de atribuição.

       \param value Novo valor da variável.

       \return Novo valor da variável.
    */
    bool operator=(bool value)
    {
        m_value.exchange(value);
        return value;
    }

private:
    /**
       \brief Conteúdo da variável atômica.
    */
    std::atomic<bool> m_value;
};

template <typename ValueT> class Atomic<ValueT*> {
public:
    /**
       \brief Constrói nova variável contendo nullptr.
    */
    Atomic() noexcept
        : m_value(nullptr)
    {
    }

    /**
       \brief Constrói nova variável contendo o valor dado.
    */
    Atomic(ValueT* value) noexcept
        : m_value(value)
    {
    }

    /**
       \brief Construtor de cópia.
    */
    Atomic(const Atomic<ValueT*>& atomic)
        : m_value(atomic)
    {
    }

    /**
       \brief Operador de atribuição.
    */
    Atomic<ValueT*>& operator=(const Atomic<ValueT*>& atomic)
    {
        if (this != &atomic)
            m_value = atomic.m_value.load();

        return *this;
    }

    /**
       \brief Retorna o valor da variável.
    */
    operator ValueT*() const { return m_value.load(); }

    /**
       \brief Retorna o valor da variável.
    */
    ValueT* load() const { return m_value.load(); }

    /**
       \brief Atualiza o valor da variável se o valor é igual ao valor de teste dado.

       É parcialmente equivalente a

       \code
           if ( variable == testValue )
             variable = updateValue;
       \endcode

       \param testValue Valor de teste da variável.

       \param updateValue Valor usado para atualizar o conteúdo da variável.

       \return True, caso o valor da variável tenha sido atualizado, e false, caso contrário.
    */
    bool testAndSet(ValueT* testValue, ValueT* updateValue)
    {
        return m_value.compare_exchange_strong(testValue, updateValue);
    }

    /**
       \brief Possivelmente, atualiza o valor da variável se o valor é igual ao valor de teste dado.

       É parcialmente equivalente a

       \code
           if ( _rand_ && variable == testValue )
             variable = updateValue;
       \endcode

       Ao contrário do testAndSet(), ela pode não atualizar o valor sempre, mas seu uso é recomendada em loops.

       \param testValue Valor de teste da variável.

       \param updateValue Valor usado para atualizar o conteúdo da variável.

       \return True, caso o valor da variável tenha sido atualizado, e false, caso contrário.
    */
    bool testAndPossiblySet(ValueT* testValue, ValueT* updateValue)
    {
        return m_value.compare_exchange_weak(testValue, updateValue);
    }

    /**
       \brief Altera o valor da variável e retorna o seu valor anterior.

       \param value Novo valor da variável.

       \return Valor anterior da variável.
    */
    ValueT* swap(ValueT* value) { return m_value.exchange(value); }

    /**
       \brief Operador de atribuição.

       \param value Valor que será atribuído à variável.

       \return Valor da variável após a atribuição.
    */
    ValueT* operator=(ValueT* value)
    {
        m_value.exchange(value);
        return value;
    }

    /**
       \brief Operador de adição e atribuição.

       \param value Valor que será adicionado ao valor da variável.

       \return Valor da variável após a adição.
    */
    ValueT* operator+=(ValueT* value)
    {
        // fetch_add retorna o valor original de m_value. Por isso, o seu resultado é adicionado a value para que o
        // valor correto seja retornado.
        return m_value.fetch_add(value) + value;
    }

    /**
       \brief Operador de subtração e atribuição.

       \param value Valor que será subtraído do valor da variável.

       \return Valor da variável após a subtração.
    */
    ValueT* operator-=(ValueT* value)
    {
        // fetch_add retorna o valor original de m_value. Por isso, o seu resultado é adicionado a value para que o
        // valor correto seja retornado.
        return m_value.fetch_sub(value) - value;
    }

    /**
       \brief Operador de pré-incremento.

       \return O valor da variável após o incremento.
    */
    ValueT* operator++() { return ++m_value; }

    /**
       \brief Operador de pós-incremento.

       \return O valor da variável antes do incremento.
    */
    ValueT* operator++(int) { return m_value++; }

    /**
       \brief Operador de pré-decremento.

       \return O valor da variável após o decremento.
    */
    ValueT* operator--() { return --m_value; }

    /**
       \brief Operador de pós-decremento.

       \return O valor da variável antes do decremento.
    */
    ValueT* operator--(int) { return m_value--; }

private:
    /**
       \brief Conteúdo da variável atômica.
    */
    std::atomic<ValueT*> m_value;
};

template <typename ValueT> class Atomic {
public:
    /**
       \brief Constrói nova variável contendo ValueT().
    */
    Atomic() noexcept
        : m_value(ValueT())
    {
    }

    /**
       \brief Constrói nova variável contendo o valor dado.
    */
    Atomic(ValueT value) noexcept
        : m_value(value)
    {
    }

    /**
       \brief Construtor de cópia.
    */
    Atomic(const Atomic<ValueT>& atomic)
        : m_value(atomic)
    {
    }

    /**
       \brief Operador de atribuição.
    */
    Atomic<ValueT>& operator=(const Atomic<ValueT>& atomic)
    {
        if (this != &atomic)
            m_value = atomic.m_value.load();

        return *this;
    }

    /**
       \brief Retorna o valor da variável.
    */
    operator ValueT() const { return m_value.load(); }

    /**
       \brief Retorna o valor da variável.
    */
    ValueT load() const { return m_value.load(); }

    /**
       \brief Atualiza o valor da variável se o valor é igual ao valor de teste dado.

       É parcialmente equivalente a

       \code
           if ( variable == testValue )
             variable = updateValue;
       \endcode

       \param testValue Valor de teste da variável.

       \param updateValue Valor usado para atualizar o conteúdo da variável.

       \return True, caso o valor da variável tenha sido atualizado, e false, caso contrário.
    */
    bool testAndSet(ValueT testValue, ValueT updateValue)
    {
        return m_value.compare_exchange_strong(testValue, updateValue);
    }

    /**
       \brief Possivelmente, atualiza o valor da variável se o valor é igual ao valor de teste dado.

       É parcialmente equivalente a

       \code
           if ( _rand_ && variable == testValue )
             variable = updateValue;
       \endcode

       Ao contrário do testAndSet(), ela pode não atualizar o valor sempre, mas seu uso é recomendada em loops.

       \param testValue Valor de teste da variável.

       \param updateValue Valor usado para atualizar o conteúdo da variável.

       \return True, caso o valor da variável tenha sido atualizado, e false, caso contrário.
    */
    bool testAndPossiblySet(ValueT testValue, ValueT updateValue)
    {
        return m_value.compare_exchange_weak(testValue, updateValue);
    }

    /**
       \brief Altera o valor da variável e retorna o seu valor anterior.

       \param value Novo valor da variável.

       \return Valor anterior da variável.
    */
    ValueT swap(ValueT value) { return m_value.exchange(value); }

    /**
       \brief Operador de atribuição.

       \param value Valor que será atribuído à variável.

       \return Valor da variável após a atribuição.
    */
    ValueT operator=(ValueT value)
    {
        m_value.exchange(value);
        return value;
    }

    /**
       \brief Operador de adição e atribuição.

       \param value Valor que será adicionado ao valor da variável.

       \return Valor da variável após a adição.
    */
    ValueT operator+=(ValueT value) { return m_value += value; }

    /**
       \brief Operador de subtração e atribuição.

       \param value Valor que será subtraido do valor da variável.

       \return Valor da variável após a subtração.
    */
    ValueT operator-=(ValueT value) { return m_value -= value; }

    /**
       \brief Operador de multiplicação e atribuição.

       \param value Valor que será multiplicado ao valor da variável.

       \return Valor da variável após a multiplicação.
    */
    ValueT operator*=(ValueT value)
    {
        // Baseado na solução apresentada em http://blogs.msdn.com/b/oldnewthing/archive/2004/09/15/229915.aspx Essa
        // solução sofre do problema ABA, descrito em http://en.wikipedia.org/wiki/ABA_problem, mas isso pode ser
        // ignorado pois o resultado final não é afetado.

        ValueT result, previousValue1, previousValue2;
        bool success;
        do {
            previousValue1 = previousValue2 = m_value;
            result = previousValue1 * value;

            // Verifica se o valor para qual a divisão foi calculada ainda é o mesmo.  Caso ele tenha sido alterado ou a
            // atualização do valor tenha falhado, a operação é refeita.
            success = m_value.compare_exchange_weak(previousValue2, result);
        } while (!success || previousValue1 != previousValue2);

        return result;
    }

    /**
       \brief Operador de divisão e atribuição.

       \param value Valor que será usado para dividir o valor da variável.

       \return Valor da variável após a divisão.
    */
    ValueT operator/=(ValueT value)
    {
        // Baseado na solução apresentada em http://blogs.msdn.com/b/oldnewthing/archive/2004/09/15/229915.aspx Essa
        // solução sofre do problema ABA, descrito em http://en.wikipedia.org/wiki/ABA_problem, mas isso pode ser
        // ignorado pois o resultado final não é afetado.

        ValueT result, previousValue1, previousValue2;
        bool success;
        do {
            previousValue1 = previousValue2 = m_value;
            result = previousValue1 / value;

            // Verifica se o valor para qual a divisão foi calculada ainda é o mesmo.  Caso ele tenha sido alterado ou a
            // atualização do valor tenha falhado, a operação é refeita.
            success = m_value.compare_exchange_weak(previousValue2, result);
        } while (!success || previousValue1 != previousValue2);

        return result;
    }

    /**
       \brief Operador de combinação bitwise-AND e atribuição.

       \param value Valor que será combinado ao valor da variável.

       \return Valor da variável após a combinação.
    */
    ValueT operator&=(ValueT value) { return m_value &= value; }

    /**
       \brief Operador de combinação bitwise-OR e atribuição.

       \param value Valor que será combinado ao valor da variável.

       \return Valor da variável após a combinação.
    */
    ValueT operator|=(ValueT value) { return m_value |= value; }

    /**
       \brief Operador de combinação bitwise-XOR e atribuição.

       \param value Valor que será combinado ao valor da variável.

       \return Valor da variável após a combinação.
    */
    ValueT operator^=(ValueT value) { return m_value ^= value; }

    /**
       \brief Operador de pré-incremento.

       \return O valor da variável após o incremento.
    */
    ValueT operator++() { return ++m_value; }

    /**
       \brief Operador de pós-incremento.

       \return O valor da variável antes do incremento.
    */
    ValueT operator++(int) { return m_value++; }

    /**
       \brief Operador de pré-decremento.

       \return O valor da variável após o decremento.
    */
    ValueT operator--() { return --m_value; }

    /**
       \brief Operador de pós-decremento.

       \return O valor da variável antes do decremento.
    */
    ValueT operator--(int) { return m_value--; }

private:
    /**
       \brief Conteúdo da variável atômica.
    */
    std::atomic<ValueT> m_value;
};

} // namespace DFF

#endif
