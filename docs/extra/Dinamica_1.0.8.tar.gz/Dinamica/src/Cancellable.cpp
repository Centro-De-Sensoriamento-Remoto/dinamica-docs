/**
   \file Cancellable.cpp

   \brief Implementações básicas usadas por entidades cuja execução pode ser cancelada.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira
*/

#include "Config.h"

#include <memory>

#include "Cancellable.h"
#include "ExceptionUtils.h"

namespace DFF {

void Cancellable::setCancelled(bool cancelled)
{
    // Guarda o valor da variável.
    m_cancelled = cancelled;

    setCancelledImpl(cancelled);
}

void Cancellable::checkCancellation() const
{
    if (isCancelled())
        throwException_(std::runtime_error, "Execution cancelled.");
}

void Cancellable::setCancelledImpl([[maybe_unused]] bool cancelled)
{
    // Faz nada.
}

bool Cancellable::isCancelled() const
{
    // Obtem o valor da variável de forma não atômica.
    return m_cancelled || (m_parent != nullptr && m_parent->isCancelled());
}

CancellationTest createCancellationTest(const std::shared_ptr<Cancellable>& cancellable)
{
    // C++ não permite que seja definido usando operador ternário ?:.
    if (cancellable != nullptr)
        return [=]() { cancellable->checkCancellation(); };
    else
        return []() {};
}

} // namespace DFF
