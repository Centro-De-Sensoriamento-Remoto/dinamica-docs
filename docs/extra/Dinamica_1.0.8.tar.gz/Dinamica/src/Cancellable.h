/**
   \file Cancellable.h

   \brief Definições básicas usadas por entidades cuja execução pode ser cancelada.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira
*/

#ifndef _DFF_CANCELLABLE_H_
#define _DFF_CANCELLABLE_H_

#include "Config.h"

#include <functional>
#include <memory>

#include "Atomic.h"

namespace DFF {

/**
   \brief Definição básica de entidades cuja execução pode ser cancelada.  (DISPONÍVEL EM JAVA)

   A execução pode ser cancelada apenas quando feita em uma thread separada.

   Tipicamente, o cancelamento da execução de uma entidade é feito da seguinte forma:

   Thread 1:

   \code
     // Re-inicia o estado da entidade.
     entity->setCancelled( false );
     // Cria a thread responsável pela execução.
     runThread2();

     // ... Espera a requisição de cancelamento ...

     // Cancela a execução.
     entity->setCancelled( true );
   \endcode

   Thread 2:

   \code
     // Executa a tarefa pela qual a entidade é responsável.
     entity->doIt();
   \endcode

   Caso seja definida a entidade pai e a entidade pai seja cancelada, essa entidade também é cancelada. Entretanto, o
   cancelamento dessa entidade não afeta a entidade pai.

   Alguns dos métodos dessa classe são "Thread-Safe", ou seja, podem ser usado simultaneamente por várias threads sem
   que sejam necessárias estruturas externas de sincronização.
*/
class DFF_PUBLIC Cancellable {
public:
    /**
       \brief Constrói uma nova entidade cuja execução pode ser cancelável.

       \param parent Entidade pai cuja execução pode ser cancelada.
    */
    Cancellable(Cancellable* parent = nullptr) noexcept
        : m_cancelled(false)
        , m_parent(parent)
    {
    }

    /**
       \brief Destructor.
    */
    virtual ~Cancellable() = default;

    /**
       \brief Configura a indicação se execução deve ser cancelada para o valor dado.

       É "Thread-Safe". Métodos "Thread-Safe" dessa classe podem ser usadas simultaneamente por várias threads sem que
       sejam necessárias estruturas externas de sincronização.

       \param cancelled Indicação se a execução deve ser cancelada.
    */
    void setCancelled(bool cancelled);

    /**
       \brief Indica se a execução deve ser cancelada.

       É "Thread-Safe". Métodos "Thread-Safe" dessa classe podem ser usadas simultaneamente por várias threads sem que
       sejam necessárias estruturas externas de sincronização.
    */
    bool isCancelled() const;

    /**
       \brief Lança ExecutionCancelledException caso a execução tenha sido cancelada.

       Pode ser usado pelas classes derivadas nas verificações de cancelamento.

       Sugere troca de contexto ao sistema para que outras threads tenham chance de executar.

       É "Thread-Safe". Métodos "Thread-Safe" dessa classe podem ser usadas simultaneamente por várias threads sem que
       sejam necessárias estruturas externas de sincronização.

       \exception ExecutionCancelledException Caso a execução tenha sido cancelada.
    */
    void checkCancellation() const;

    /**
       \brief Define a entidade pai.

       \param parent Entidade pai cuja execução pode ser cancelada. Caso seja 0, a entidade não terá entidade pai.
    */
    void setParent(Cancellable* parent) { m_parent = parent; }

    /**
       \brief Retorna a entidade pai, caso esteja definida.

       \attention O pointer retornado não deve ser desalocado.
    */
    Cancellable* getParent() const { return m_parent; }

protected:
    /**
       \brief Implementação responsável pela execução de tarefas adicionais quando a indicação se a execução deve ser
       cancelada é alterada.

       É executado em um contexto "Thread-Safe". Métodos "Thread-Safe" dessa classe podem ser usadas simultaneamente por
       várias threads sem que sejam necessárias estruturas externas de sincronização.

       \param cancelled Indicação se a execução deve ser cancelada.
    */
    virtual void setCancelledImpl(bool cancelled);

private:
    /**
       \brief Indica se a execução ou o agendamento da execução deve ser cancelada.
    */
    Atomic<bool> m_cancelled;

    /**
       \brief Entidade pai da entidade cuja execução pode ser cancelada.
    */
    Cancellable* m_parent;
};

/**
   \brief Assinatura da função responsável por verificar o cancelamento da execução.

   Caso a execução tenha sido cancelada, a função deve lançar ExecutionCancelledException.
*/
using CancellationTest = std::function<void()>;

/**
   \brief Cria função responsável por verificar o cancelamento da execução a partir de entidade cuja execução pode ser
   cancelada.

   \param cancellable Entidade cuja execução pode ser cancelada. Caso seja definido, a verificação do cancelamento não
   tem efeito.
*/
DFF_PUBLIC CancellationTest createCancellationTest(
    const std::shared_ptr<Cancellable>& cancellable = std::shared_ptr<Cancellable>());

} // namespace DFF

#endif
