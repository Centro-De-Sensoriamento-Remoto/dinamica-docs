/**
   \file FileTaggedMessageQueue.h

   \brief Fila de mensagens (com tag) utilizando um arquivo para leitura e escrita.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#ifndef _DFF_FILE_TAGGED_MESSAGE_QUEUE_H_
#define _DFF_FILE_TAGGED_MESSAGE_QUEUE_H_

#include "Config.h"

#include <cstring>
#include <filesystem>
#include <string>

#include "Cancellable.h"

#ifdef _DFF_ON_WINDOWS_
#define _WINDOWS_
#endif

#define MAX_MESSAGE_TAG_LENGTH 512

namespace fs = std::filesystem;

namespace DFF {

/**
   \brief Escreve e lê mensagens em um arquivo.

   Essas mensagens são transferidas usando uma string como Tag, e são lidas apenas através das tags. Se uma tag é
   escrita mais de uma vez, a mensagem anterior relativa a tag é sobrescrita.

   As operações de leitura e escrita dessa classe são O(n).
*/

class DFF_PUBLIC FileTaggedMessageQueue {
public:
    /**
       \brief Cabeçalho do arquivo contendo as mensagens.
    */
    struct Header {

        /**
           \brief Tamanho do bloco de mensagem.
        */
        uint64_t blockSize;

        /**
           \brief Quantidade de blocos alocados.
        */
        uint64_t blockCount;
    };

    /**
       \brief Cabeçalho de cada mensagem armazenada no arquivo.
    */
    struct MessageHeader {

        /**
           \brief Armazena se o slot utilizado pela mensagem está em uso.
        */
        bool inUse;

        /**
           \brief Tag usada para identificar a mensagem.
        */
        char tag[MAX_MESSAGE_TAG_LENGTH];

        MessageHeader() = default;
        MessageHeader(bool inUse, const std::string& passedTag)
            : inUse(inUse)
        {

            setTag(passedTag);
        }

        /**
           \brief Copia a tag passada para a estrutura interna da tag.
        */
        void setTag(const std::string& passedTag)
        {
            const std::size_t minSize = std::min(std::size_t(MAX_MESSAGE_TAG_LENGTH - 1), passedTag.length());

            memcpy(tag, passedTag.c_str(), minSize);
            tag[MAX_MESSAGE_TAG_LENGTH - 1] = 0;
        }

        /**
           \brief Compara a tag passada com a tag armazenada na mensagem.
         */
        bool hasTag(const std::string& passedTag) const
        {
            const std::size_t minCompareSize = std::min(std::size_t(MAX_MESSAGE_TAG_LENGTH), passedTag.length());

            for (std::size_t i = 0; i < minCompareSize; ++i)
                if (tag[i] != passedTag[i])
                    return false;

            return true;
        }
    };

    /**
       \brief Cria um novo arquivo contendo uma fila de mensagens.

       \param filename Nome do arquivo contendo as mensagens.

       \param messageSize Tamanho em bytes das mensagens a serem gravadas.

       \param messageCount Número máximo de mensagens a serem gravadas no arquivo.
    */
    FileTaggedMessageQueue(const fs::path& filename, std::size_t messageSize, std::size_t messageCount);

    /**
       \brief Abre um arquivo contendo uma fila de mensagens.

       \param filename Nome do arquivo contendo as mensagens.
    */
    FileTaggedMessageQueue(const fs::path& filename);

    /**
       \brief Escreve uma mensagem na fila. Bloqueia se a fila estiver cheia.

       \param tag String contendo a tag usada para gravação da mensagem. Caso a tag já exista no arquivo, ela será
       substituída.

       \param data Ponteiro para o buffer de dados a ser escrito.

       \param size Número de bytes a serem escritos.

       \param cancellationTest Função responsável por verificar o cancelamento da execução.
    */
    void write(const std::string& tag, const void* data, std::size_t size,
        CancellationTest cancellationTest = createCancellationTest());

    /**
       \brief Lê uma mensagem da fila. Bloqueia se a fila estiver vazia.

       \param data Ponteiro para o buffer de dados onde as informações lidas serão gravadas.

       \param size Número de bytes a serem lidos.

       \param cancellationTest Função responsável por verificar o cancelamento da execução.
    */
    void read(const std::string& tag, void* data, std::size_t size,
        CancellationTest cancellationTest = createCancellationTest());

    /**
       \brief Destrói os arquivos utilizados por uma fila.

       \param filename Nome de arquivo utilizado para criação da fila.
    */
    static void destroy(const fs::path& filename);

    /**
       \brief Retorna o número máximo de mensagens que podem ser gravadas no arquivo.
    */
    inline const std::size_t getMaximumMessageCount() const { return m_maximumMessageCount; }

private:
    /**
       \brief Nome do arquivo onde a fila de mensagem está salva.
    */
    fs::path m_filename;

    /**
       \brief Tamanho (em bytes) de cada mensagem armazenada na fila.
    */
    std::size_t m_messageSize;

    /**
       \brief Armazena o número máximo de mensagens que podem ser armazenadas.
    */
    std::size_t m_maximumMessageCount;
};

} // namespace DFF

#endif
