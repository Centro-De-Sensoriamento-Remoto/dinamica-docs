/**
   \file StringUtils.cpp

   \brief Implementação de utilitários para a manipulação e para a conversão de valores para strings.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <memory>
#include <sstream>
#include <string>
#include <vector>

#ifdef _DFF_ON_WINDOWS_
#include <windows.h>
#else
#include <codecvt>
#include <locale>
#endif

#include "ExceptionUtils.h"
#include "StringUtils.h"

namespace {

#define RAW_STRING_PREFIX "$\""
#define RAW_STRING_PREFIX_SEPARATOR "("
#define RAW_STRING_SUFFIX_SEPARATOR ")"
#define RAW_STRING_SUFFIX "\""

// Caracteres que necessitam de escape devem ter um escape a mais adicionado para evitar que o spirit faça parsing
// adicional.
const std::set<std::string> escapedReservedChars { "\\x", "\\X", "\\o", "\\O", "\\u", "\\U" };

// Lista de todos os caracteres que tenham que ser colocados um escape, para diferenciação em relação a caracteres
// reservados, para correta leitura/escrita da String.
const std::set<char> reservedChars { '"' };

/**
   \brief Codifica a string passada para Base64.

   Código vindo de uma thread no StackOverflow com testes de performance.
   https://stackoverflow.com/questions/342409/how-do-i-base64-encode-decode-in-c/41094722#41094722

   Copyright (c) 2005-2011, Jouni Malinen <j@w1.fi> Copyright (c) 2016, Gaspard Petit

   This software may be distributed under the terms of the BSD license.  See README for more details.
*/
std::string base64Encode(const std::string& input)
{
    static const unsigned char base64Table[65] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                                 "abcdefghijklmnopqrstuvwxyz"
                                                 "0123456789+/";

    unsigned char* out = nullptr;
    unsigned char* pos = nullptr;
    const unsigned char* endChar = nullptr;
    const unsigned char* inputChar = nullptr;

    /* 3-byte blocks to 4-byte */
    size_t outputLength = 4 * ((input.size() + 2) / 3);
    if (outputLength < input.size())
        throwException_(std::runtime_error, "Failed to allocate output string.");

    std::string outStr;
    outStr.resize(outputLength);
    out = (unsigned char*)&outStr[0];

    endChar = (const unsigned char*)input.c_str() + input.size();
    inputChar = (const unsigned char*)input.c_str();
    pos = out;

    while (endChar - inputChar >= 3) {
        *pos++ = base64Table[inputChar[0] >> 2];
        *pos++ = base64Table[((inputChar[0] & 0x03) << 4) | (inputChar[1] >> 4)];
        *pos++ = base64Table[((inputChar[1] & 0x0f) << 2) | (inputChar[2] >> 6)];
        *pos++ = base64Table[inputChar[2] & 0x3f];
        inputChar += 3;
    }

    if (endChar - inputChar) {
        *pos++ = base64Table[inputChar[0] >> 2];
        if (endChar - inputChar == 1) {
            *pos++ = base64Table[(inputChar[0] & 0x03) << 4];
            *pos++ = '=';
        } else {
            *pos++ = base64Table[((inputChar[0] & 0x03) << 4) | (inputChar[1] >> 4)];
            *pos++ = base64Table[(inputChar[1] & 0x0f) << 2];
        }

        *pos++ = '=';
    }

    return outStr;
}

/**
   \brief Decodifica a string Base64 passada.

   Código vindo de uma thread no StackOverflow com testes de performance.
   https://stackoverflow.com/questions/342409/how-do-i-base64-encode-decode-in-c/41094722#41094722

   Código do decoder feito por "polfosol" na thread:
   https://stackoverflow.com/questions/180947/base64-decode-snippet-in-c
*/
std::string base64Decode(const std::string& input)
{
    static const int base64Index[256] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 62, 63, 62, 62, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61,
        0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
        25, 0, 0, 0, 0, 63, 0, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
        48, 49, 50, 51 };

    const size_t inputLength = input.size();

    unsigned char* charPtr = (unsigned char*)input.c_str();
    const bool shouldPad = (inputLength > 0) && (inputLength % 4 || charPtr[inputLength - 1] == '=');

    const std::size_t shouldPadNum = shouldPad ? 1 : 0;
    const size_t length = ((inputLength + 3) / 4 - shouldPadNum) * 4;
    std::string outputString((length / 4 * 3 + shouldPadNum), '\0');

    for (size_t i = 0, j = 0; i < length; i += 4) {
        int64_t n = base64Index[charPtr[i]] << 18 | base64Index[charPtr[i + 1]] << 12 | base64Index[charPtr[i + 2]] << 6
                    | base64Index[charPtr[i + 3]];

        outputString[j++] = (n >> 16);
        outputString[j++] = (n >> 8 & 0xFF);
        outputString[j++] = (n & 0xFF);
    }

    if (shouldPad) {
        int64_t n = (base64Index[charPtr[length]] << 18) | (base64Index[charPtr[length + 1]] << 12);

        outputString[outputString.size() - 1] = (n >> 16);
        if ((input.size() > length + 2) && (charPtr[length + 2] != '=')) {
            n |= base64Index[charPtr[length + 2]] << 6;
            outputString.push_back(n >> 8 & 0xFF);
        }
    }

    return outputString;
}

} // namespace
namespace DFF {

void StringUtils::valueToField(std::string& field, int value, std::size_t fieldSize)
{
    field = DFF::toString(value);

    // Trunca os limites do campo para valores razoáveis.
    if (fieldSize > 30)
        fieldSize = 30;

    for (std::size_t i = field.size(); i < fieldSize; ++i)
        field = "0" + field;
}

std::string StringUtils::toUTF8(const std::wstring& input)
{
#ifdef _DFF_ON_WINDOWS_
    // Solução obtida no endereço http://mariusbancila.ro/blog/2008/10/20/writing-utf-8-files-in-c/

    int outputLength =
        ::WideCharToMultiByte(CP_UTF8, 0, input.c_str(), static_cast<int>(input.length()), NULL, 0, NULL, NULL);

    std::string output;

    if (outputLength != 0) {
        output.resize(outputLength);

        ::WideCharToMultiByte(CP_UTF8, 0, input.c_str(), static_cast<int>(input.length()),
            const_cast<char*>(output.c_str()), outputLength, NULL, NULL);
    }

    return output;
#else
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> conv;
    return conv.to_bytes(input);
#endif
}

std::wstring StringUtils::fromUTF8(std::string_view input)
{
#ifdef _DFF_ON_WINDOWS_
    const int nChars = ::MultiByteToWideChar(CP_UTF8, 0, input.data(), static_cast<int>(input.length()), 0, 0);

    if (nChars == 0)
        return std::wstring();

    std::wstring newbuffer;
    newbuffer.resize(nChars);
    ::MultiByteToWideChar(
        CP_UTF8, 0, input.data(), static_cast<int>(input.length()), const_cast<wchar_t*>(newbuffer.c_str()), nChars);

    return newbuffer;
#else
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> conv;
    return conv.from_bytes(input.data(), input.data() + input.length());
#endif
}

std::string StringUtils::returnEscapedString(const std::string& value)
{
    std::string changedString;
    changedString.reserve(value.size() * 2);

    for (std::size_t i = 0; i < value.size(); ++i) {
        const char c = value[i];
        const char nextC = value[i + 1 < value.size() ? i + 1 : i];
        const std::string escapedStr { c, nextC };

        const bool isReservedChar = reservedChars.find(c) != reservedChars.end();
        const bool isEscapedReservedChar = escapedReservedChars.find(escapedStr) != escapedReservedChars.end();

        if (isReservedChar || isEscapedReservedChar)
            changedString += "\\";

        if (!isReservedChar && isEscapedReservedChar) {
            changedString += escapedStr;
            i++;
        } else {
            changedString += c;
        }
    }

    return changedString;
}

std::string StringUtils::makeRawString(const std::string& value)
{
    if (value.find(RAW_STRING_SUFFIX_SEPARATOR RAW_STRING_SUFFIX) == std::string::npos) {
        return (RAW_STRING_PREFIX RAW_STRING_PREFIX_SEPARATOR) + value
               + (RAW_STRING_SUFFIX_SEPARATOR RAW_STRING_SUFFIX);

    } else {
        std::size_t delimiterId = 0;
        std::string delimiterStr = DFF::toString(delimiterId);

        while (value.find(RAW_STRING_SUFFIX_SEPARATOR + delimiterStr + RAW_STRING_SUFFIX) != std::string::npos)
            delimiterStr = DFF::toString(++delimiterId);

        return RAW_STRING_PREFIX + delimiterStr + RAW_STRING_PREFIX_SEPARATOR + value + RAW_STRING_SUFFIX_SEPARATOR
               + delimiterStr + RAW_STRING_SUFFIX;
    }
}

void StringUtils::putEscapeIntoReservedChars(std::string& value) { value = returnEscapedString(value); }

std::string StringUtils::convertToBase64(const std::string& value) { return base64Encode(value); }

std::string StringUtils::convertFromBase64(const std::string& value) { return base64Decode(value); }

std::string StringUtils::returnUnescapedString(const std::string& value)
{
    std::string changedString;

    // Reserva o tamanho máximo da string alterada, que não passará do tamanho da string original, uma vez que só são
    // retirados escapes de caracteres especiais.
    changedString.reserve(value.size());

    for (std::size_t i = 0; i < value.size(); ++i) {
        const char c = value[i];
        const char nextC = value[i + 1 < value.size() ? i + 1 : i];

        const std::string escapedStr { c, nextC };

        const bool isReservedCharEscape = c == '\\' && reservedChars.find(nextC) != reservedChars.end();
        const bool isReservedEscapedCharEscape =
            i > 0 && value[i - 1] == '\\' && escapedReservedChars.find(escapedStr) != escapedReservedChars.end();

        if (!isReservedCharEscape && !isReservedEscapedCharEscape) {
            changedString += c;
        }
    }

    return changedString;
}

void StringUtils::removeEscapeIntoReservedChars(std::string& value) { value = returnUnescapedString(value); }

std::string StringUtils::toR(const std::string& inputString)
{
    std::string resultString;

    void* resourcePtr = Riconv_open("", "UTF-8");
    if (resourcePtr != nullptr) {
        std::vector<char> inBuffer, outBuffer;
        for (char ch : inputString)
            inBuffer.push_back(ch);

        inBuffer.push_back(0);
        outBuffer.resize(inputString.length() * 2 + 1, 0);

        const char* inputStr = inBuffer.data();
        char* outputStr = outBuffer.data();

        size_t inSize = inputString.length();
        size_t outSize = outBuffer.size();

        size_t resultSize = Riconv(resourcePtr, &inputStr, &inSize, &outputStr, &outSize);

        int64_t outputStringStartOffset = outBuffer.size() - outSize;
        size_t outputStringSize = static_cast<size_t>(std::max((int64_t)0, outputStringStartOffset));

        Riconv_close(resourcePtr);

        if (outputStringSize > 0 && inSize == 0 && resultSize != static_cast<size_t>(-1)) {
            resultString = std::string(outBuffer.data(), outputStringSize);
        }
    }

    if (resultString.empty())
        resultString = inputString;

    return resultString;
}

} // namespace DFF

std::string operator+(const char* input1, std::string_view input2)
{
    std::string result(input1);
    result += input2;

    return result;
}

std::string operator+(std::string_view input1, const char* input2)
{
    std::string result(input1);
    result += input2;

    return result;
}

std::string operator+(const std::string& input1, std::string_view input2)
{
    std::string result(input1);
    result += input2;

    return result;
}

std::string operator+(std::string_view input1, const std::string& input2)
{
    std::string result(input1);
    result += input2;

    return result;
}
