/**
   \file SimpleParser.h

   \brief Definição de um parser simples para strings.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#ifndef _DFF_SIMPLE_PARSER_H_
#define _DFF_SIMPLE_PARSER_H_

#include "Config.h"

#include <cctype>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <sstream>

#include "ExceptionUtils.h"

namespace DFF {

namespace SimpleParser {

    /**
       \brief Definição da regra básica de todos os parsers
     */
    struct DFF_PUBLIC Rule {
        std::string contents;
        bool operator==(const char& c) const;
        bool operator!=(const char& c) const;
        bool operator==(const std::string& str) const;
        bool operator!=(const std::string& str) const;
        friend std::ostream& operator<<(std::ostream& str, const Rule& a)
        {
            str << a.contents << " ";
            return str;
        }
    };

    /**
       \brief Tipo de ação que o parser pode tomar.
     */
    enum class RuleAction { DEFAULT = 0, LOOK_AHEAD = 1 };

    /**
       \brief Classe responsável por guardar as informações (contexto) onde o parser será executado.
     */
    class DFF_PUBLIC Context {
    public:
        Context(const std::string& input);

        /**
           \brief Retorna a posição atual do cursor da stream.
         */
        std::istringstream::pos_type tell();

        /**
           \brief Move o cursor da stream para a posição especificada.
         */
        void seek(std::istringstream::pos_type pos);

        /**
           \brief Retorna se a stream já atingiu EOF
         */
        bool eof() const;

        /**
           \brief Retorna a stream para ser modificada
         */
        std::istringstream& getStream();

        /**
           \brief Cria uma regra e retorna uma cópia do resultado.

           Aceita um parametro opcional dizendo se a regra é um look ahead ou não.
         */
        template <typename T> Rule parse(RuleAction peekOnly = RuleAction::DEFAULT) { return T(*this, peekOnly); }

        /**
           \brief Cria uma regra e retorna uma cópia do resultado.

           Aceita dois parametros, um argumento qualquer e um parametro opcional dizendo se a regra é um look ahead ou
           não.
         */
        template <typename T, typename A> Rule parse(A arg1, RuleAction peekOnly = RuleAction::DEFAULT)
        {
            return T(*this, arg1, peekOnly);
        }

    private:
        std::istringstream m_stream;
    };

    /**
       \brief Regra responsável pelo parsing de um caractere
     */
    struct DFF_PUBLIC RuleChar : public Rule {
        RuleChar(Context& ctx, RuleAction peekOnly = RuleAction::DEFAULT);
        RuleChar(Context& ctx, const char c, RuleAction peekOnly = RuleAction::DEFAULT);
    };

    /**
       \brief Regra responsável pelo parsing de uma palavra entre espaços ou terminada em \r, \n
     */
    struct DFF_PUBLIC RuleWord : public Rule {
        RuleWord(Context& ctx, RuleAction peekOnly = RuleAction::DEFAULT);
        RuleWord(Context& ctx, const char c, RuleAction peekOnly = RuleAction::DEFAULT);
    };

    /**
       \brief Regra responsável pelo parsing de uma palavra entre aspas duplas.
     */
    struct DFF_PUBLIC RuleQuotedWord : public Rule {
        RuleQuotedWord(Context& ctx, RuleAction peekOnly = RuleAction::DEFAULT);
    };

    typedef RuleQuotedWord quotedWord;
    typedef RuleWord word;
    typedef RuleChar char_;

} // namespace SimpleParser

} // namespace DFF

#endif
