/**
   \file FileTaggedMessageQueue.cpp

   \brief Fila de mensagens (com tag) utilizando um arquivo para leitura e escrita.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <thread>

#include "ExceptionUtils.h"
#include "FileTaggedMessageQueue.h"
#include "FilenameLock.h"
#include "FilesystemUtils.h"

#ifdef _DFF_ON_WINDOWS_
#define _WINDOWS_
#endif

#define BLOCK_SLEEP_INTERVAL_MS std::chrono:: milliseconds(100)

namespace fs = std::filesystem;

namespace DFF {

namespace {

    /**
       \brief Permite o uso de variáveis opcionais.

       É necessário declarar o próprio optional aqui uma vez que o código do R depende desse arquivo e std::optional não
       pode ser usado.
    */
    template <typename T> class Optional {
    public:
        Optional()
            : m_value()
            , m_initialized(false)
        {
        }

        T value() const
        {
            if (!m_initialized)
                throwException_(std::runtime_error, "Value is not initialized.");

            return m_value;
        }

        Optional& operator=(const T& rhs)
        {
            m_value = rhs;
            m_initialized = true;

            return *this;
        }

        explicit operator bool() const noexcept { return m_initialized; }

    private:
        T m_value;
        bool m_initialized;
    };

    inline void writeHeader(std::fstream& stream, const DFF::FileTaggedMessageQueue::Header& header)
    {
        stream.seekp(0);
        stream.write((char*)&header, sizeof(DFF::FileTaggedMessageQueue::Header));
        stream.flush();
    }

    template <typename T> DFF::FileTaggedMessageQueue::Header getHeader(T& stream)
    {
        DFF::FileTaggedMessageQueue::Header header;

        stream.seekg(0);
        stream.read((char*)&header, sizeof(DFF::FileTaggedMessageQueue::Header));

        return header;
    }

    inline void writeMessageHeader(std::fstream& stream, const DFF::FileTaggedMessageQueue::MessageHeader& header)
    {
        stream.write((char*)&header, sizeof(DFF::FileTaggedMessageQueue::MessageHeader));
        stream.flush();
    }

    inline void writeMessage(std::fstream& stream, const DFF::FileTaggedMessageQueue::MessageHeader& header,
        const void* data, std::size_t dataLength)
    {
        writeMessageHeader(stream, header);
        stream.write(static_cast<const char*>(data), dataLength);
        stream.flush();
    }

    template <typename T> DFF::FileTaggedMessageQueue::MessageHeader getMessageHeader(T& stream)
    {
        DFF::FileTaggedMessageQueue::MessageHeader header;

        stream.read((char*)&header, sizeof(DFF::FileTaggedMessageQueue::MessageHeader));
        return header;
    }

    // Concatena a extensão usada pelo arquivo de lock ao fs::path passado.
    fs::path lockSuffix(const fs::path& path)
    {
        fs::path copiedPath(path);
        copiedPath += FILENAME_LOCK_SUFFIX;
        return copiedPath;
    }

} // namespace
FileTaggedMessageQueue::FileTaggedMessageQueue(
    const fs::path& filename, std::size_t messageSize, std::size_t messageCount)
    : m_filename(filename)
    , m_messageSize(messageSize)
    , m_maximumMessageCount(messageCount)
{
    // Obtém a trava exclusiva para criação do arquivo (como supõe-se que o arquivo não existe, dispara se a trava
    // existir).
    fs::path lockFilename(lockSuffix(m_filename));
    FilenameLock lock(lockFilename, FilenameLock::LockBehavior::THROW_ON_BUSY);

    std::string filenameString = DFF::FilesystemUtils::genericString(m_filename);

    // Verifica se a sessão já existe.
    if (std::ifstream(m_filename, std::ios::in).is_open())
        throwException_(std::runtime_error,
            "Failed to create tagged message queue \"" << filenameString << "\". Session already exist.");

    // Cria o arquivo em modo binário.
    std::fstream handle(m_filename, std::ios::out | std::ios::binary | std::ios::trunc);

    if (handle.is_open() == false)
        throwException_(std::runtime_error, "Failed to create tagged message queue \"" << filenameString << "\".");

    // Escreve o cabeçalho com as informações
    const FileTaggedMessageQueue::Header header = { messageSize, messageCount };
    writeHeader(handle, header);

    // Escreve no arquivo bytes suficientes para acomodar todas as mensagens.
    const FileTaggedMessageQueue::MessageHeader msgHeader = {};

    char* tmpData = new char[messageSize];
    memset(tmpData, 0, messageSize);

    for (std::size_t i = 0; i < messageCount; ++i) {
        writeMessage(handle, msgHeader, tmpData, messageSize);
    }

    delete[] tmpData;
}

FileTaggedMessageQueue::FileTaggedMessageQueue(const fs::path& filename)
    : m_filename(filename)
{

    // Obtém a trava exclusiva para leitura do arquivo.
    const fs::path lockFilename(lockSuffix(m_filename));
    const FilenameLock lock(lockFilename);

    std::ifstream handle(m_filename, std::ios::in | std::ios::out | std::ios::binary);

    if (handle.is_open() == false)
        throwException_(std::runtime_error,
            "Failed to open tagged message queue \"" << DFF::FilesystemUtils::genericString(m_filename) << "\".");

    // Recupera o cabeçalho para preencher o tamanho da mensagem armazenada.
    const FileTaggedMessageQueue::Header header(getHeader(handle));
    m_messageSize = header.blockSize;
    m_maximumMessageCount = header.blockCount;
}

void FileTaggedMessageQueue::write(
    const std::string& tag, const void* data, std::size_t size, CancellationTest cancellationTest)
{
    while (true) {
        const fs::path lockFilename(lockSuffix(m_filename));
        FilenameLock lock(lockFilename);

        std::fstream handle(m_filename, std::ios::in | std::ios::out | std::ios::binary);

        if (handle.is_open() == false)
            throwException_(std::runtime_error,
                "Failed to open tagged message queue \"" << DFF::FilesystemUtils::genericString(m_filename) << "\".");

        // Reseta o ponteiro no arquivo e salta o cabeçalho.
        getHeader(handle);
        const std::size_t messagesStartIndex = handle.tellg();

        // Procura o índice da mensagem com o tag especificado ou o primeiro slot disponível, caso a tag não apareça em
        // nenhuma mensagem.
        Optional<std::size_t> messageSlot;
        for (std::size_t i = 0; i < m_maximumMessageCount; ++i) {
            handle.seekg(messagesStartIndex + i * (m_messageSize + sizeof(FileTaggedMessageQueue::MessageHeader)));

            const FileTaggedMessageQueue::MessageHeader msgHeader(getMessageHeader(handle));

            // Uma vez que a tag é encontrada, a busca pode ser encerrada.
            if (msgHeader.inUse && msgHeader.hasTag(tag)) {
                messageSlot = i;
                break;
            }

            // Verifica se o slot está disponível, caso a tag não seja encontrada.
            if (!msgHeader.inUse && !messageSlot) {
                messageSlot = i;
            }
        }

        // Foi encontrado um slot para gravação da mensagem ou uma mensagem com a mesma tag existente.
        if (messageSlot) {
            handle.seekg(messagesStartIndex
                         + messageSlot.value() * (m_messageSize + sizeof(FileTaggedMessageQueue::MessageHeader)));

            writeMessage(handle, { true, tag }, data, size);
            break;
        }

        // Libera o lock e espera um timeout para uma nova tentativa.
        lock.release();
        std::this_thread::sleep_for(BLOCK_SLEEP_INTERVAL_MS);

        cancellationTest();
    }
}

void FileTaggedMessageQueue::read(
    const std::string& tag, void* data, std::size_t size, CancellationTest cancellationTest)
{
    while (true) {
        const fs::path lockFilename(lockSuffix(m_filename));
        FilenameLock lock(lockFilename);

        std::fstream handle(m_filename, std::ios::in | std::ios::out | std::ios::binary);

        if (handle.is_open() == false)
            throwException_(std::runtime_error,
                "Failed to open tagged message queue \"" << DFF::FilesystemUtils::genericString(m_filename) << "\".");

        // Reseta o ponteiro no arquivo e salta o cabeçalho.
        getHeader(handle);

        const std::size_t messagesStartIndex = handle.tellg();
        for (std::size_t i = 0; i < m_maximumMessageCount; ++i) {
            handle.seekg(messagesStartIndex + i * (m_messageSize + sizeof(FileTaggedMessageQueue::MessageHeader)));

            const FileTaggedMessageQueue::MessageHeader msgHeader(getMessageHeader(handle));

            if (msgHeader.inUse && msgHeader.hasTag(tag)) {
                handle.read((char*)data, size);

                // Após ser lida, a mensagem deve ser marcada no arquivo.
                handle.seekg(messagesStartIndex + i * (m_messageSize + sizeof(FileTaggedMessageQueue::MessageHeader)));

                writeMessageHeader(handle, { false, "\0" });
                return;
            }
        }

        // Libera o lock e espera um timeout para uma nova tentativa.
        lock.release();
        std::this_thread::sleep_for(BLOCK_SLEEP_INTERVAL_MS);

        cancellationTest();
    }
}

void FileTaggedMessageQueue::destroy(const fs::path& filename)
{
    try {
        DFF::FilesystemUtils::removeFileOrFolder(lockSuffix(filename));

    } catch (std::exception& e) {
        // Evita que falhas na remoção do arquivo cancelem as demais remoções.
    }

    try {
        DFF::FilesystemUtils::removeFileOrFolder(filename);

    } catch (std::exception& e) {
        // Evita que falhas na remoção do arquivo cancelem as demais remoções.
    }
}

} // namespace DFF
