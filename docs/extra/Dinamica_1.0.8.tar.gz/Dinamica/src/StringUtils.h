/**
   \file StringUtils.h

   \brief Definição de utilitários para a manipulação e conversão de valores para strings.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira
*/

#ifndef _DFF_STRING_UTILS_H_
#define _DFF_STRING_UTILS_H_

#include "Config.h"

#include <algorithm>
#include <deque>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include <R_ext/Riconv.h>

namespace fs = std::filesystem;

namespace DFF {

/**
   \brief Utilitários usados na manipulação de string.
*/
class DFF_PUBLIC StringUtils {
public:
    /**
       \brief Atualiza string dado com a representação de valor usando, no mínimo, o número especificado de dígitos.

       Para isso, são acrescentados zeros à esquerda do valor até o número de dígitos seja igual ao número especificado.

       \param field String que conterá o resultado.

       \param value Valor que será representado.

       \param fieldSize Número de dígitos que serão usados para representar o valor. Caso o valor seja menor que o
       número de dígitos do valor, será usado o valor sem modificações. Caso seja maior que 30, será usado 30.
    */
    static void valueToField(std::string& field, int value, std::size_t fieldSize);

    /**
       \brief Converte a representaçao do texto para o formato UTF8 (https://en.wikipedia.org/wiki/UTF-8).

       Em GNU/Linux as strings já estão representadas em UTF-8 e não precisam ser convertidas para wstring.

       \param input Texto que será convertido.
    */
    static std::string toUTF8(const std::wstring& input);

    /**
       \brief Converte a representaçao de texto do formato UTF8 (https://en.wikipedia.org/wiki/UTF-8) para WideChar.

       Em GNU/Linux as strings já estão representadas em UTF-8 e não precisam ser convertidas para wstring.

       \param input Texto que será convertido.
    */
    static std::wstring fromUTF8(std::string_view input);

    /**
       \brief Retorna uma string que seja corretamente validada no parser, colocando escape em caracteres que são
       reservados no Dinamica.

       \param value String base para modificação.
  */
    static std::string returnEscapedString(const std::string& value);

    /**
       \brief Altera a string recebida para que possa conter qualquer caractere interno que pudesse ser inválido sem que
       atrapalhe o funcionamento.
    */
    static std::string makeRawString(const std::string& value);

    /**
       \brief Altera a string recebida para que seja corretamente validada no parser, colocando escape em caracteres que
       são reservados no Dinamica.

       \param value String a ser alterada.
    */
    static void putEscapeIntoReservedChars(std::string& value);

    /**
       \brief Transforma o valor de string passado em Base64.
    */
    static std::string convertToBase64(const std::string& value);

    /**
       \brief Transforma o valor de string Base64 passado em uma string regular.
    */
    static std::string convertFromBase64(const std::string& value);

    /**
       \brief Retorna a string original escrita pelo usuário, sem os escapes colocados para leitura.

       \param value String base para modificação.
    */
    static std::string returnUnescapedString(const std::string& value);

    /**
       \brief Altera a string passada para a original escrita pelo usuário, sem os escapes colocados para leitura.

       \param value String a ser alterada.
    */
    static void removeEscapeIntoReservedChars(std::string& value);

    static std::string toR(const std::string& input);
};

// Declara que existe operator<< para std::map< std::string, ValueT > para ser utilizado na definição a seguir de
// std::vector< ValueT >.
template <typename ValueT> std::ostream& operator<<(std::ostream& os, const std::map<std::string, ValueT>& values);
template <typename KeyT, typename ValueT>
std::ostream& operator<<(std::ostream& os, const std::map<KeyT, ValueT>& values);

/**
   \brief Converte o objeto dado para a representação equivalente.

   \param value Valor. É necessário que o operator<<( ostream&, const T& ) esteja definido para o valor de tipo T dado.

   \param precisionBase Precisão usada na conversão, no caso de valores reais, e base usada na representação, no caso de
   valores inteiros. O valor padrão -1 indica, no caso de valores reais, que deve ser usado o número máximo de dígitos
   necessários para representar o tipo sem perda de precisão, e, no caso de valores inteiros, que será usada a base
   padrão.

   \param fixed Indica se a precisão na conversão de valores reais será usada ou como número de dígitos após o separador
   decimal ou como número de dígitos significativos.
*/
template <typename T> std::string toString(const T& val, int precisionBase = -1, bool fixed = false);

template <>
inline std::string toString<std::string>(const std::string& value, int /* precisionBase */, bool /* fixed */)
{
    return value;
}

template <> inline std::string toString<float>(const float& value, int precisionBase, bool fixed)
{
    std::ostringstream stream;

    stream.precision(precisionBase < 0 ? std::numeric_limits<float>::digits10 : precisionBase);

    if (fixed)
        stream << std::fixed << value;
    else
        stream << value;

    return stream.str();
}

template <> inline std::string toString<double>(const double& value, int precisionBase, bool fixed)
{
    std::ostringstream stream;

    stream.precision(precisionBase < 0 ? std::numeric_limits<double>::digits10 : precisionBase);

    if (fixed)
        stream << std::fixed << value;
    else
        stream << value;

    return stream.str();
}

template <> inline std::string toString<unsigned long>(const unsigned long& value, int precisionBase, bool /* fixed */)
{
    if (precisionBase < 0) {
        // Assume base 10 para a representação.

        std::ostringstream stream;

        stream << value;

        return stream.str();

    } else {
        // Usa outra base para a representação.

        // Ess definição foi adaptada a partir da versão disponível no http://arachnoid.com/cpptutor/student3.html.

        const std::string digits = "0123456789abcdef";

        unsigned long value2 = value;
        std::string result;

        do {
            result = digits[static_cast<std::size_t>(value2 % precisionBase)] + result;
            value2 /= precisionBase;

        } while (value2);

        return result;
    }
}

template <> inline std::string toString<unsigned int>(const unsigned int& value, int precisionBase, bool /* fixed */)
{
    return toString(static_cast<unsigned long>(value), precisionBase, false);
}

template <typename T> std::string toString(const T& value, int /* precisionBase */, bool /* fixed */)
{
    std::ostringstream stream;

    stream << value;

    return stream.str();
}

/**
  \brief Converte a constante string para a representação equivalente no objeto string.

  Essa definição evita problemas caso ::toString seja aplicado erroneamente a uma constante string.

  \param val Valor.
*/
inline std::string toString(const char* val) { return std::string(val); }

/**
   \brief Definição do operador "<<" usado por arranjos (vectors).

   \param os Stream de saída.

   \param values Arranjo dado.
*/
template <typename ValueT> inline std::ostream& operator<<(std::ostream& os, const std::vector<ValueT>& values);

template <> inline std::ostream& operator<< <std::string>(std::ostream& os, const std::vector<std::string>& values)
{
    os << "[";

    if (!values.empty()) {
        for (std::vector<std::string>::const_iterator i = values.begin(); i != values.end();) {
            os << " \"" << *i << "\"";

            ++i;
            if (i != values.end())
                os << ",";
            else
                os << " ";
        }
    }

    os << "]";

    return os;
}

template <typename ValueT> inline std::ostream& operator<<(std::ostream& os, const std::vector<ValueT>& values)
{
    os << "[";

    if (!values.empty()) {
        for (typename std::vector<ValueT>::const_iterator i = values.begin(); i != values.end();) {
            os << " " << *i;

            ++i;
            if (i != values.end())
                os << ",";
            else
                os << " ";
        }
    }

    os << "]";

    return os;
}

/**
   \brief Essa definição permite que o operador "<<" usado por pares (pairs) seja especializado parcialmente.
*/
template <typename ValueT1, typename ValueT2> class PairToStream;

template <> class PairToStream<std::string, std::string> {
public:
    static std::ostream& pairToStream(std::ostream& os, const std::pair<std::string, std::string>& value)
    {
        return os << "(\"" << value.first << "\", \"" << value.second << "\")";
    }
};

template <typename ValueT2> class PairToStream<std::string, ValueT2> {
public:
    static std::ostream& pairToStream(std::ostream& os, const std::pair<std::string, ValueT2>& value)
    {
        return os << "(\"" << value.first << "\", " << value.second << ")";
    }
};

template <typename ValueT1> class PairToStream<ValueT1, std::string> {
public:
    static std::ostream& pairToStream(std::ostream& os, const std::pair<ValueT1, std::string>& value)
    {
        return os << "(" << value.first << ", \"" << value.second << "\")";
    }
};

template <typename ValueT1, typename ValueT2> class PairToStream {
public:
    static std::ostream& pairToStream(std::ostream& os, const std::pair<ValueT1, ValueT2>& value)
    {
        return os << "(" << value.first << ", " << value.second << ")";
    }
};

/**
   \brief Definição do operador "<<" usado por pares (pairs).

   \param os Stream de saída.

   \param value Par dado.
*/
template <typename ValueT1, typename ValueT2>
inline std::ostream& operator<<(std::ostream& os, const std::pair<ValueT1, ValueT2>& values);

inline std::ostream& operator<<(std::ostream& os, const std::pair<std::string, std::string>& value)
{
    return PairToStream<std::string, std::string>::pairToStream(os, value);
}

template <typename ValueT2>
inline std::ostream& operator<<(std::ostream& os, const std::pair<std::string, ValueT2>& value)
{
    return PairToStream<std::string, ValueT2>::pairToStream(os, value);
}

template <typename ValueT1>
inline std::ostream& operator<<(std::ostream& os, const std::pair<ValueT1, std::string>& value)
{
    return PairToStream<ValueT1, std::string>::pairToStream(os, value);
}

template <typename ValueT1, typename ValueT2>
inline std::ostream& operator<<(std::ostream& os, const std::pair<ValueT1, ValueT2>& value)
{
    return PairToStream<ValueT1, ValueT2>::pairToStream(os, value);
}

/**
   \brief Definição do operador "<<" usado por conjuntos (set).

   \param os Stream de saída.

   \param values Conjunto dado.
*/
template <typename ValueT> inline std::ostream& operator<<(std::ostream& os, const std::set<ValueT>& values);

template <> inline std::ostream& operator<< <std::string>(std::ostream& os, const std::set<std::string>& values)
{
    os << "[";

    if (!values.empty()) {
        for (std::set<std::string>::const_iterator i = values.begin(); i != values.end();) {
            os << " \"" << *i << "\"";

            ++i;
            if (i != values.end())
                os << ",";
            else
                os << " ";
        }
    }

    os << "]";

    return os;
}

template <typename ValueT> inline std::ostream& operator<<(std::ostream& os, const std::set<ValueT>& values)
{
    os << "[";

    if (!values.empty()) {
        for (typename std::set<ValueT>::const_iterator i = values.begin(); i != values.end();) {
            os << " " << *i;

            ++i;
            if (i != values.end())
                os << ",";
            else
                os << " ";
        }
    }

    os << "]";

    return os;
}

/**
   \brief Definição do operador "<<" usado por filas duplas (deque).

   \param os Stream de saída.

   \param values Fila dupla dado.
*/
template <typename ValueT> inline std::ostream& operator<<(std::ostream& os, const std::deque<ValueT>& values);

template <> inline std::ostream& operator<< <std::string>(std::ostream& os, const std::deque<std::string>& values)
{
    os << "[";

    if (!values.empty()) {
        for (std::deque<std::string>::const_iterator i = values.begin(); i != values.end();) {
            os << " \"" << *i << "\"";

            ++i;
            if (i != values.end())
                os << ",";
            else
                os << " ";
        }
    }

    os << "]";

    return os;
}

template <typename ValueT> inline std::ostream& operator<<(std::ostream& os, const std::deque<ValueT>& values)
{
    os << "[";

    if (!values.empty()) {
        for (typename std::deque<ValueT>::const_iterator i = values.begin(); i != values.end();) {
            os << " " << *i;

            ++i;
            if (i != values.end())
                os << ",";
            else
                os << " ";
        }
    }

    os << "]";

    return os;
}

/**
   \brief Essa definição permite que o operador "<<" usado por mapeamentos (maps) seja especializado parcialmente.
*/
template <typename KeyT, typename ValueT> class MapToStream;

template <> class MapToStream<std::string, std::string> {
public:
    static std::ostream& mapToStream(std::ostream& os, const std::map<std::string, std::string>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (std::map<std::string, std::string>::const_iterator i = values.begin(); i != values.end();) {
                os << " \"" << i->first << "\", \"" << i->second << "\")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

template <typename ValueT> class MapToStream<std::string, ValueT> {
public:
    static std::ostream& mapToStream(std::ostream& os, const std::map<std::string, ValueT>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (typename std::map<std::string, ValueT>::const_iterator i = values.begin(); i != values.end();) {
                os << " (\"" << i->first << "\", " << i->second << ")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

template <typename KeyT> class MapToStream<KeyT, std::string> {
public:
    static std::ostream& mapToStream(std::ostream& os, const std::map<KeyT, std::string>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (typename std::map<KeyT, std::string>::const_iterator i = values.begin(); i != values.end();) {
                os << " " << i->first << ", \"" << i->second << "\")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

template <typename KeyT, typename ValueT> class MapToStream {
public:
    static std::ostream& mapToStream(std::ostream& os, const std::map<KeyT, ValueT>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (typename std::map<KeyT, ValueT>::const_iterator i = values.begin(); i != values.end();) {
                os << " (" << i->first << ", " << i->second << ")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

/**
   \brief Definição do operador "<<" usado por mapeamentos (maps).

   \param os Stream de saída.

   \param values Mapeamento dado.
*/
template <typename KeyT, typename ValueT>
inline std::ostream& operator<<(std::ostream& os, const std::map<KeyT, ValueT>& values);

inline std::ostream& operator<<(std::ostream& os, const std::map<std::string, std::string>& values)
{
    return MapToStream<std::string, std::string>::mapToStream(os, values);
}

template <typename ValueT>
inline std::ostream& operator<<(std::ostream& os, const std::map<std::string, ValueT>& values)
{
    return MapToStream<std::string, ValueT>::mapToStream(os, values);
}

template <typename KeyT> inline std::ostream& operator<<(std::ostream& os, const std::map<KeyT, std::string>& values)
{
    return MapToStream<KeyT, std::string>::mapToStream(os, values);
}

template <typename KeyT, typename ValueT>
inline std::ostream& operator<<(std::ostream& os, const std::map<KeyT, ValueT>& values)
{
    return MapToStream<KeyT, ValueT>::mapToStream(os, values);
}

/**
   \brief Essa definição permite que o operador "<<" usado por mapeamentos múltiplos (multimaps) seja especializado
   parcialmente.
*/
template <typename KeyT, typename ValueT> class MultiMapToStream;

template <> class MultiMapToStream<std::string, std::string> {
public:
    static std::ostream& multiMapToStream(std::ostream& os, const std::multimap<std::string, std::string>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (std::multimap<std::string, std::string>::const_iterator i = values.begin(); i != values.end();) {
                os << " \"" << i->first << "\", \"" << i->second << "\")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

template <typename ValueT> class MultiMapToStream<std::string, ValueT> {
public:
    static std::ostream& multiMapToStream(std::ostream& os, const std::multimap<std::string, ValueT>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (typename std::multimap<std::string, ValueT>::const_iterator i = values.begin(); i != values.end();) {
                os << " (\"" << i->first << "\", " << i->second << ")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

template <typename KeyT> class MultiMapToStream<KeyT, std::string> {
public:
    static std::ostream& multiMapToStream(std::ostream& os, const std::multimap<KeyT, std::string>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (typename std::map<KeyT, std::string>::const_iterator i = values.begin(); i != values.end();) {
                os << " " << i->first << ", \"" << i->second << "\")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

template <typename KeyT, typename ValueT> class MultiMapToStream {
public:
    static std::ostream& multiMapToStream(std::ostream& os, const std::multimap<KeyT, ValueT>& values)
    {
        os << "[";

        if (!values.empty()) {
            for (typename std::multimap<KeyT, ValueT>::const_iterator i = values.begin(); i != values.end();) {
                os << " (" << i->first << ", " << i->second << ")";

                ++i;
                if (i != values.end())
                    os << ",";
                else
                    os << " ";
            }
        }

        os << "]";

        return os;
    }
};

/**
   \brief Definição do operador "<<" usado por mapeamentos múltiplos (multimaps).

   \param os Stream de saída.

   \param values Mapeamento dado.
*/
template <typename KeyT, typename ValueT>
inline std::ostream& operator<<(std::ostream& os, const std::multimap<KeyT, ValueT>& values);

inline std::ostream& operator<<(std::ostream& os, const std::multimap<std::string, std::string>& values)
{
    return MultiMapToStream<std::string, std::string>::multiMapToStream(os, values);
}

template <typename ValueT>
inline std::ostream& operator<<(std::ostream& os, const std::multimap<std::string, ValueT>& values)
{
    return MultiMapToStream<std::string, ValueT>::multiMapToStream(os, values);
}

template <typename KeyT>
inline std::ostream& operator<<(std::ostream& os, const std::multimap<KeyT, std::string>& values)
{
    return MultiMapToStream<KeyT, std::string>::multiMapToStream(os, values);
}

template <typename KeyT, typename ValueT>
inline std::ostream& operator<<(std::ostream& os, const std::multimap<KeyT, ValueT>& values)
{
    return MultiMapToStream<KeyT, ValueT>::multiMapToStream(os, values);
}

} // namespace DFF

/**
   \brief Definição do operador "+" usado para concatenar std::string, "const char *" e std::string_view e vice-versa.
*/

DFF_PUBLIC std::string operator+(const char* input1, std::string_view input2);

DFF_PUBLIC std::string operator+(std::string_view input1, const char* input2);

DFF_PUBLIC std::string operator+(const std::string& input1, std::string_view input2);

DFF_PUBLIC std::string operator+(std::string_view input1, const std::string& input2);

#endif
