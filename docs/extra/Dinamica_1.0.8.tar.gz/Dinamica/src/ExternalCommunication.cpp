/**
   \file ExternalCommunication.cpp

   \brief Utilitário para comunicação com aplicações externas.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>

#include "ExceptionUtils.h"
#include "ExternalCommunication.h"
#include "FilesystemUtils.h"

namespace fs = std::filesystem;

namespace DFF {

namespace {

    /**
       \brief Retorna o caminho completo para o arquivo da sessão com tags.  O caminho retornado é o caminho do
       diretório temporário acrescido do nome de base passado pelo usuário e o sufixo '.tagQueue'.

       \param baseName Nome de base a ser usado para sessão.
    */
    fs::path getTaggedSessionName(const std::string& baseName)
    {
        return fs::u8path(DFF::FilesystemUtils::getCompleteTemporaryPath(baseName + ".tagQueue"));
    }

    /**
       \brief Retorna o caminho completo para o arquivo da sessão.  O caminho retornado é o caminho do diretório
       temporário acrescido do nome de base passado pelo usuário e o sufixo '.queue'.

       \param baseName Nome de base a ser usado para sessão.
    */
    fs::path getSessionName(const std::string& baseName)
    {
        return fs::u8path(DFF::FilesystemUtils::getCompleteTemporaryPath(baseName + ".queue"));
    }

} // namespace

ExternalCommunication::ExternalCommunication()
    : m_sessionCreated(false)
{
}

ExternalCommunication::~ExternalCommunication()
{
    try {
        destroy();

    } catch (std::exception& e) {
        // Evita que falhas na limpeza da sessão causem lançamento de exceções pelo destructor.
    }
}

void ExternalCommunication::createSession(const std::string& sessionIdentifier)
{
    if (m_sessionCreated)
        throwException_(std::runtime_error, "A session named \"" << m_sessionIdentifier << "\" already exists.");

    const fs::path receiveQueueName(getSessionName(sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX));

    const fs::path receiveTagQueueName(getTaggedSessionName(sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX));

    const fs::path sendQueueName(getSessionName(sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX));

    const fs::path sendTagQueueName(getTaggedSessionName(sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX));

    auto newReceiveQueue = std::make_shared<FileMessageQueue>(receiveQueueName, sizeof(Message), QUEUE_MAX_MESSAGES);

    auto newTagReceiveQueue =
        std::make_shared<FileTaggedMessageQueue>(receiveTagQueueName, sizeof(Message), QUEUE_MAX_MESSAGES);

    auto newSendQueue = std::make_shared<FileMessageQueue>(sendQueueName, sizeof(Message), QUEUE_MAX_MESSAGES);

    auto newTagSendQueue =
        std::make_shared<FileTaggedMessageQueue>(sendTagQueueName, sizeof(Message), QUEUE_MAX_MESSAGES);

    // Atribuição feita tardiamente para que a classe não fique em um estado inconsistente caso alguma exceção seja
    // disparada.
    try {
        m_receiveQueue = newReceiveQueue;
        m_tagReceiveQueue = newTagReceiveQueue;
        m_sendQueue = newSendQueue;
        m_tagSendQueue = newTagSendQueue;
        m_sessionIdentifier = sessionIdentifier;
        m_sessionCreated = true;

    } catch (...) {
        m_receiveQueue.reset();
        m_tagReceiveQueue.reset();
        m_sendQueue.reset();
        m_tagSendQueue.reset();
        m_sessionIdentifier.clear();
        m_sessionCreated = false;

        throw;
    }
}

void ExternalCommunication::destroy()
{
    // Apenas apaga os objetos se a instância tiver sido responsável pela criação das sessões.
    if (m_sessionCreated) {
        m_receiveQueue.reset();
        m_sendQueue.reset();
        m_tagReceiveQueue.reset();
        m_tagSendQueue.reset();
        destroySession(m_sessionIdentifier);

        m_sessionIdentifier.clear();
        m_sessionCreated = false;
    }
}

void ExternalCommunication::openSession(const std::string& sessionIdentifier)
{
    if (m_sessionCreated)
        throwException_(std::runtime_error, "A session named \"" << m_sessionIdentifier << "\" already exists.");

    try {
        m_sessionIdentifier = sessionIdentifier;
        m_receiveQueue =
            std::make_shared<FileMessageQueue>(getSessionName(m_sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX));

        m_tagReceiveQueue = std::make_shared<FileTaggedMessageQueue>(
            getTaggedSessionName(m_sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX));

        m_sendQueue =
            std::make_shared<FileMessageQueue>(getSessionName(m_sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX));

        m_tagSendQueue = std::make_shared<FileTaggedMessageQueue>(
            getTaggedSessionName(m_sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX));

    } catch (std::exception& ex) {

        m_sessionIdentifier.clear();
        m_receiveQueue.reset();
        m_sendQueue.reset();
        m_tagReceiveQueue.reset();
        m_tagSendQueue.reset();

        throwException_(
            std::runtime_error, "Failed to open session \"" << sessionIdentifier << "\", reason: " << ex.what());
    }
}

void ExternalCommunication::sendMessage(
    const Message& message, const std::string& tag, CancellationTest cancellationTest)
{
    if (m_sendQueue == nullptr || m_tagSendQueue == nullptr || m_tagReceiveQueue == nullptr
        || m_receiveQueue == nullptr) {

        throwException_(std::runtime_error, "Failed to send message, session is closed.");
    }

    try {
        if (tag.empty())
            m_sendQueue->write(&message, sizeof(Message), cancellationTest);
        else
            m_tagSendQueue->write(tag, &message, sizeof(Message), cancellationTest);
    } catch (std::exception& ex) {
        throwException_(std::runtime_error,
            "Failed to send external message (identifier: " << message.m_identifier << ", number: " << message.m_number
                                                            << ", handle: " << message.getString()
                                                            << "). Reason: " << ex.what() << ".");
    }
}

DFF::ExternalCommunication::Message ExternalCommunication::receiveMessage(
    const std::string& tag, CancellationTest cancellationTest)
{
    if (m_sendQueue == nullptr || m_tagSendQueue == nullptr || m_tagReceiveQueue == nullptr
        || m_receiveQueue == nullptr) {

        throwException_(std::runtime_error, "Failed to send message, session is closed.");
    }

    Message receivedMessage;
    try {
        if (tag.empty())
            m_receiveQueue->read(&receivedMessage, sizeof(Message), cancellationTest);
        else
            m_tagReceiveQueue->read(tag, &receivedMessage, sizeof(Message), cancellationTest);

        return receivedMessage;

    } catch (std::exception& ex) {
        throwException_(std::runtime_error, "Failed to receive external message: " << ex.what());
    }
}

void ExternalCommunication::destroySession(const std::string& identifier)
{
    DFF::FileMessageQueue::destroy(getSessionName(identifier + SHARED_QUEUE_CLIENT_SUFFIX));

    DFF::FileTaggedMessageQueue::destroy(getTaggedSessionName(identifier + SHARED_QUEUE_CLIENT_SUFFIX));

    DFF::FileMessageQueue::destroy(getSessionName(identifier + SHARED_QUEUE_SERVER_SUFFIX));

    DFF::FileTaggedMessageQueue::destroy(getTaggedSessionName(identifier + SHARED_QUEUE_SERVER_SUFFIX));
}

bool ExternalCommunication::sessionExists(const std::string& identifier)
{
    const fs::path clientIdentifier(getSessionName(identifier + SHARED_QUEUE_CLIENT_SUFFIX));
    const fs::path serverIdentifier(getSessionName(identifier + SHARED_QUEUE_SERVER_SUFFIX));

    const fs::path clientTagIdentifier(getTaggedSessionName(identifier + SHARED_QUEUE_CLIENT_SUFFIX));
    const fs::path serverTagIdentifier(getTaggedSessionName(identifier + SHARED_QUEUE_SERVER_SUFFIX));

    return DFF::FilesystemUtils::filenameExists(clientIdentifier)
           || DFF::FilesystemUtils::filenameExists(serverIdentifier)
           || DFF::FilesystemUtils::filenameExists(clientTagIdentifier)
           || DFF::FilesystemUtils::filenameExists(serverTagIdentifier);
}

std::size_t ExternalCommunication::getMaxNumberOfMessages() const
{
    if (m_sendQueue == nullptr || m_tagSendQueue == nullptr || m_tagReceiveQueue == nullptr
        || m_receiveQueue == nullptr) {

        throwException_(std::runtime_error, "Failed to return maximum number of unqueued messages, session is closed.");
    }

    return m_sendQueue->getMaximumMessageCount();
}

void ExternalCommunication::storeNumbersOnFilename(
    std::size_t numberCount, const std::function<double(std::size_t)>& getNumber, const fs::path& filename)
{

    std::ofstream handle(filename, std::ios_base::out | std::ios_base::trunc | std::ios_base::binary);

    if (handle.is_open() == false)
        throwException_(std::runtime_error, "Failed to create temporary file \"" << DFF::FilesystemUtils::genericString(
                                                filename) << "\" to store number vector.");

    if (numberCount > std::numeric_limits<int>::max())
        throwException_(std::runtime_error, "List is too big to be communicated. "
                                                << "Actual size " << numberCount << ", maximum size "
                                                << std::numeric_limits<int>::max());

    const int listCount = static_cast<int>(numberCount);
    handle.write((char*)&listCount, sizeof(int));

    for (std::size_t i = 0; i < numberCount; ++i) {
        const double number = getNumber(i);
        handle.write((char*)&number, sizeof(double));
    }

    handle.close();
}

void ExternalCommunication::getNumbersFromFilename(
    const std::function<void(double)>& setNumber, const fs::path& filename)
{

    std::ifstream handle(filename, std::ios_base::in | std::ios_base::binary);

    if (handle.is_open() == false)
        throwException_(std::runtime_error, "Failed to read temporary file \"" << DFF::FilesystemUtils::genericString(
                                                filename) << "\" of stored number vector.");

    int numCount = 0;
    handle.read((char*)&numCount, sizeof(int));

    for (int i = 0; i < numCount; ++i) {
        double inDouble = 0;
        handle.read((char*)&inDouble, sizeof(double));
        setNumber(inDouble);
    }
}

// Evita que bibliotecas externas incluam arquivos do Dinamica.
#ifdef _DINAMICA_EGO_

ExternalCommunication& ExternalCommunicationManager::Instance()
{
    return SingletonHolder<ExternalCommunication>::Instance();
}

#endif

std::ostream& operator<<(std::ostream& os, ExternalMessageTypes type)
{
    switch (type) {
    case ExternalMessageTypes::NUMBER:
        os << "Number";
        break;
    case ExternalMessageTypes::NUMBER_LIST:
        os << "Number List";
        break;
    case ExternalMessageTypes::LOOKUP_TABLE:
        os << "Lookup Table";
        break;
    case ExternalMessageTypes::STRING:
        os << "String";
        break;
    case ExternalMessageTypes::ERROR_DESCRIPTION:
        os << "Error Description";
        break;
    default:
        // O cast é necessário para evitar recursão.
        os << "Unknown (" << static_cast<int>(type) << ")";
        break;
    }

    return os;
}

} // namespace DFF
