/**
   \file FileMessageQueue.h

   \brief Fila de mensagens utilizando um arquivo para leitura e escrita.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#ifndef _DFF_FILE_MESSAGE_QUEUE_H_
#define _DFF_FILE_MESSAGE_QUEUE_H_

#include "Config.h"

#include <filesystem>
#include <string>

#include "Cancellable.h"

#ifdef _DFF_ON_WINDOWS_
#define _WINDOWS_
#endif

namespace fs = std::filesystem;

namespace DFF {

class DFF_PUBLIC FileMessageQueue {
public:
    /**
       \brief Cabeçalho do arquivo contendo as mensagens.
    */
    struct Header {
        /**
           \brief Posição do cabeçote de leitura.
        */
        uint64_t readPtr;

        /**
           \brief Posição do cabeçote de escrita.
        */
        uint64_t writePtr;

        /**
           \brief Tamanho do bloco de mensagem.
        */
        uint64_t blockSize;

        /**
           \brief Quantidade de blocos alocados.
        */
        uint64_t blockCount;
    };

    /**
       \brief Cria um novo arquivo contendo uma fila de mensagens.

       \param filename Nome do arquivo contendo as mensagens.

       \param messageSize Tamanho em bytes das mensagens a serem gravadas.

       \param messageCount Número máximo de mensagens a serem gravadas no arquivo.
    */
    FileMessageQueue(const fs::path& filename, std::size_t messageSize, std::size_t messageCount);

    /**
       \brief Abre um arquivo contendo uma fila de mensagens.

       \param filename Nome do arquivo contendo as mensagens.

       \param accessType O arquivo será criado para escrita. O único valor aceito para esse parametro é
       AccessType::OPEN.
    */
    FileMessageQueue(const fs::path& filename);

    /**
       \brief Escreve uma mensagem na fila. Bloqueia se a fila estiver cheia.

       Caso a fila esteja cheia, bloqueia até que a mensagem possa ser enviada.

       \param data Ponteiro para o buffer de dados a ser escrito.

       \param size Número de bytes a serem escritos.

       \param cancellationTest Função responsável por verificar o cancelamento da execução.
    */
    void write(const void* data, std::size_t size, CancellationTest cancellationTest = createCancellationTest());

    /**
       \brief Lê uma mensagem da fila. Bloqueia se a fila estiver vazia.

       \param data Ponteiro para o buffer de dados onde as informações lidas serão gravadas.

       \param size Número de bytes a serem lidos.

       \param cancellationTest Função responsável por verificar o cancelamento da execução.
    */
    void read(void* data, std::size_t size, CancellationTest cancellationTest = createCancellationTest());

    /**
       \brief Destrói os arquivos utilizados por uma fila.

       \param filename Nome de arquivo utilizado para criação da fila.
    */
    static void destroy(const fs::path& filename);

    /**
       \brief Retorna o número máximo de mensagens que podem ser gravadas no arquivo.
    */
    inline const std::size_t getMaximumMessageCount() const { return m_maximumMessageCount; }

private:
    /**
       \brief Nome do arquivo onde a fila de mensagem está salva.
    */
    fs::path m_filename;

    /**
       \brief Tamanho (em bytes) de cada mensagem armazenada na fila.
    */
    std::size_t m_messageSize;

    /**
       \brief Armazena o número máximo de mensagens que podem ser armazenadas.
    */
    std::size_t m_maximumMessageCount;
};

} // namespace DFF

#endif
