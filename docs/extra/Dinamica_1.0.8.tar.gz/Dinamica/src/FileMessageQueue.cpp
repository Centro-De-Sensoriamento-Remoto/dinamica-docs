/**
   \file FileMessageQueue.cpp

   \brief Fila de mensagens utilizando um arquivo para leitura e escrita.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <thread>

#include "ExceptionUtils.h"
#include "FileMessageQueue.h"
#include "FilenameLock.h"
#include "FilesystemUtils.h"

#ifdef _DFF_ON_WINDOWS_
#define _WINDOWS_
#endif

#define BLOCK_SLEEP_INTERVAL_MS std::chrono::milliseconds(100)

namespace DFF {

namespace fs = std::filesystem;

namespace {

    void writeHeader(std::fstream& stream, const DFF::FileMessageQueue::Header& header)
    {
        stream.seekp(0);
        stream.write((char*)&header, sizeof(DFF::FileMessageQueue::Header));
        stream.flush();
    }

    template <typename T> DFF::FileMessageQueue::Header getHeader(T& stream)
    {
        DFF::FileMessageQueue::Header header;

        stream.seekg(0);
        stream.read((char*)&header, sizeof(DFF::FileMessageQueue::Header));

        return header;
    }

    // Concatena a extensão usada pelo arquivo de lock ao fs::path passado.
    fs::path lockSuffix(const fs::path& path)
    {
        fs::path copiedPath(path);
        copiedPath += FILENAME_LOCK_SUFFIX;
        return copiedPath;
    }

} // namespace

FileMessageQueue::FileMessageQueue(const fs::path& filename, std::size_t messageSize, std::size_t messageCount)
    : m_filename(filename)
    , m_messageSize(messageSize)
    , m_maximumMessageCount(messageCount)
{
    // Obtém a trava exclusiva para criação do arquivo (como supõe-se que o arquivo não existe, dispara se a trava
    // existir).
    fs::path lockFilename(lockSuffix(m_filename));
    FilenameLock lock(lockFilename, FilenameLock::LockBehavior::THROW_ON_BUSY);

    std::string filenameString = DFF::FilesystemUtils::genericString(m_filename);

    // Verifica se a sessão já existe.
    if (std::ifstream(m_filename, std::ios::in).is_open())
        throwException_(
            std::runtime_error, "Failed to create message queue \"" << filenameString << "\". Session already exist.");

    // Cria o arquivo em modo binário.
    std::ofstream handle(m_filename, std::ios::out | std::ios::binary | std::ios::trunc);

    if (handle.is_open() == false)
        throwException_(std::runtime_error, "Failed to create message queue \"" << filenameString << "\".");

    // Escreve o cabeçalho com as informações
    const FileMessageQueue::Header header = { 0, 0, messageSize, messageCount };
    handle.write((char*)&header, sizeof(FileMessageQueue::Header));
    handle.flush();

    // Escreve no arquivo bytes suficientes para acomodar todas as mensagens.
    char* data = new char[messageSize * messageCount];
    memset(data, 0, messageSize * messageCount);

    handle.write(data, messageSize * messageCount);
    handle.flush();

    delete[] data;
}

FileMessageQueue::FileMessageQueue(const fs::path& filename)
    : m_filename(filename)
{
    // Obtém a trava exclusiva para leitura do arquivo.
    const fs::path lockFilename(lockSuffix(m_filename));
    const FilenameLock lock(lockFilename);

    std::ifstream handle(m_filename, std::ios::in | std::ios::out | std::ios::binary);

    if (handle.is_open() == false)
        throwException_(std::runtime_error,
            "Failed to open message queue \"" << DFF::FilesystemUtils::genericString(m_filename) << "\".");

    // Recupera o cabeçalho para preencher o tamanho da mensagem armazenada.
    const FileMessageQueue::Header header(getHeader(handle));
    m_messageSize = header.blockSize;
    m_maximumMessageCount = header.blockCount;
}

void FileMessageQueue::write(const void* data, std::size_t size, CancellationTest cancellationTest)
{
    while (true) {
        const fs::path lockFilename(lockSuffix(m_filename));
        FilenameLock lock(lockFilename);

        std::fstream handle(m_filename, std::ios::in | std::ios::out | std::ios::binary);

        if (handle.is_open() == false)
            throwException_(std::runtime_error,
                "Failed to open message queue \"" << DFF::FilesystemUtils::genericString(m_filename) << "\".");

        FileMessageQueue::Header header(getHeader(handle));

        // Enquanto o ponteiro de escrita não alcançar o ponteiro de leitura, a escrita pode ser feita.
        const std::size_t nextWritePtr = (header.writePtr + 1) % header.blockCount;
        if (nextWritePtr != header.readPtr) {
            std::size_t offset = sizeof(FileMessageQueue::Header) + header.writePtr * header.blockSize;

            handle.seekp(offset);
            handle.write((const char*)data, size);
            handle.flush();

            header.writePtr = nextWritePtr;
            writeHeader(handle, header);

            break;
        }

        // Libera o lock e espera um timeout para uma nova tentativa.
        lock.release();
        std::this_thread::sleep_for(BLOCK_SLEEP_INTERVAL_MS);

        cancellationTest();
    }
}

void FileMessageQueue::read(void* data, std::size_t size, CancellationTest cancellationTest)
{
    while (true) {
        const fs::path lockFilename(lockSuffix(m_filename));
        FilenameLock lock(lockFilename);

        std::fstream handle(m_filename, std::ios::in | std::ios::out | std::ios::binary);

        if (handle.is_open() == false)
            throwException_(std::runtime_error,
                "Failed to open message queue \"" << DFF::FilesystemUtils::genericString(m_filename) << "\".");

        FileMessageQueue::Header header(getHeader(handle));

        // Uma leitura pode ser feita desde que os dois ponteiros não estejam na mesma posição.
        if (header.readPtr != header.writePtr) {
            std::size_t offset = sizeof(FileMessageQueue::Header) + header.readPtr * header.blockSize;

            handle.seekp(offset);
            handle.read((char*)data, size);

            header.readPtr = (header.readPtr + 1) % header.blockCount;
            writeHeader(handle, header);

            break;
        }

        // Libera o lock e espera um timeout para uma nova tentativa.
        lock.release();
        std::this_thread::sleep_for(BLOCK_SLEEP_INTERVAL_MS);

        cancellationTest();
    }
}

void FileMessageQueue::destroy(const fs::path& filename)
{
    try {
        DFF::FilesystemUtils::removeFileOrFolder(lockSuffix(filename));

    } catch (std::exception& e) {
        // Evita que falhas na remoção do arquivo cancelem as demais remoções.
    }

    try {
        DFF::FilesystemUtils::removeFileOrFolder(filename);

    } catch (std::exception& e) {
        // Evita que falhas na remoção do arquivo cancelem as demais remoções.
    }
}

} // namespace DFF
