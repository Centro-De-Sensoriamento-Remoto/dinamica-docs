/**
   \file Registry.h

   \brief Conjunto de funções para acessar os registros.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado

   \author Francisco de Paula Dias Neto
*/

#ifndef _DFF_REGISTRY_H_
#define _DFF_REGISTRY_H_

#include "Config.h"

#include <iostream>
#include <map>
#include <mutex>
#include <ostream>
#include <string>

#define REG_KEY_PREFIX "DINAMICA_EGO_8_"

namespace DFF {

const std::string_view REG_CL_CONFIG_KEY(REG_KEY_PREFIX "CL_CONFIG");

const std::string_view REG_CL_DEVICES_LIST_KEY(REG_KEY_PREFIX "CL_DEVICES");

const std::string_view REG_GDAL_DATA_PATH_KEY(REG_KEY_PREFIX "GDAL_DATA");

const std::string_view REG_GDAL_TOOL_DATA_PATH_KEY(REG_KEY_PREFIX "GDAL_TOOLS_DATA");

const std::string_view REG_GDAL_TOOL_PATH_KEY(REG_KEY_PREFIX "GDAL_TOOLS");

const std::string_view REG_INSTALLATION_DIRECTORY_KEY(REG_KEY_PREFIX "INSTALLATION_DIRECTORY");

const std::string_view REG_MAC_EXECUTABLE_PATH_KEY(REG_KEY_PREFIX "MAC_DEV_PATH");

const std::string_view REG_MAXIMUM_DETECTED_CORES_KEY(REG_KEY_PREFIX "MAX_DETECTED_CORES");

const std::string_view REG_MEMORY_ALLOCATION_POLICY_KEY(REG_KEY_PREFIX "MEMORY_ALLOCATION_POLICY");

const std::string_view REG_R_ALTERNATIVE_PATH_KEY(REG_KEY_PREFIX "ALTERNATIVE_PATH_FOR_R");

const std::string_view REG_R_CRAN_MIRROR_KEY(REG_KEY_PREFIX "R_CRAN_MIRROR");

const std::string_view REG_TEMPORARY_DIRECTORY_KEY(REG_KEY_PREFIX "TEMP_DIR");

#ifndef _DFF_ON_WINDOWS_
const std::string_view ENV_PATH_DIR(REG_KEY_PREFIX "PATH");
#endif

/**
   \brief Acesso aos registros do ambiente, do sistema e do usuário.
*/
class DFF_PUBLIC Registry {
public:
    /**
       \brief Tipos de registro a serem usados nas funções *RegistryProperty.
    */
    enum class Type {

        /**
           \brief Variável de ambiente do processo.
        */
        ENVIRONMENT,

        /**
           \brief Registro de cada usuário.

           No Windows, HKEY_CURRENT_USER.  Em POSIX, $HOME/.$POSIX_CONFIG_FILE
        */
        USER,

        /**
           \brief Registro do sistema.

           No Windows, HKEY_LOCAL_MACHINE.  Em POSIX, /etc/$POSIX_CONFIG_FILE
        */
        SYSTEM
    };

    /**
       \brief Recupera uma string contendo o valor para a chave passada no registro desejado.

       \exception Caso a chave não exista, uma exceção será disparada.
     */
    std::string getProperty(std::string_view key, Type regType, bool ignoreCache = false);

    /**
       \brief Recupera uma string contendo o valor para a chave passada no registro desejado e armazena no parâmetro
       value.

       Caso a chave não exista, é retornado false.
    */
    bool getPropertyIfExists(std::string_view key, std::string& value, Type regType, bool ignoreCache = false);

    /**
       \brief Recupera uma string contendo o valor para a chave passada na propriedade desejada.

       A propridade é buscada sempre respeitando a prioridade:
       1) Variável de Ambiente;
       2) Registro do Usuário;
       3) Registro do Sistema.

       \exception Caso a chave não exista.
     */
    std::string getAutoProperty(std::string_view key, bool ignoreCache = false);

    /**
       \brief Recupera uma string contendo o valor para a chave passada no registro desejado e armazena no parâmetro
       value.

       Caso a chave não exista, é retornado false.

       A propriedade é buscada sempre respeitando a prioridade:
       1) Variável de Ambiente;
       2) Registro do Usuário;
       3) Registro do Sistema.
    */
    bool getAutoPropertyIfExists(std::string_view key, std::string& value, bool ignoreCache = false);

    /**
       \brief Retorna se uma dada chave existe, no registro desejado.
    */
    bool hasProperty(std::string_view key, Type regType, bool ignoreCache = false) const;

    /**
       \brief Retorna se uma dada chave existe.

       A propriedade é buscada sempre respeitando a prioridade:
       1) Variável de Ambiente;
       2) Registro do Usuário;
       3) Registro do Sistema.
    */
    bool hasAutoProperty(std::string_view key, bool ignoreCache = false) const;

private:
    /**
       \brief Retorna o cache de registro correspondente ao tipo requerido.

       O uso de std::less<> na definição da relação permite "transparent comparison" nas buscas, de modo que seja
       possível passar valor "equivalente" às chaves, mas de tipos diferentes.
    */
    const std::map<std::string, std::string, std::less<>>& getRegistryCacheByType(Type regType) const;

    /**
       \brief Retorna o cache de registro correspondente ao tipo requerido.

       O uso de std::less<> na definição da relação permite "transparent comparison" nas buscas, de modo que seja
       possível passar valor "equivalente" às chaves, mas de tipos diferentes.
    */
    std::map<std::string, std::string, std::less<>>& getRegistryCacheByType(Type regType);

    /**
       \brief Coloca um registro no Cache.
    */
    void setRegistryInCache(Type regType, std::string_view regKey, std::string_view value);

    /**
       \brief Coloca vários registros no Cache.

       O uso de std::less<> na definição da relação permite "transparent comparison" nas buscas, de modo que seja
       possível passar valor "equivalente" às chaves, mas de tipos diferentes.
    */
    void setRegistriesInCache(Type regType, const std::map<std::string, std::string, std::less<>>& registries);

    /**
       \brief Retorna o registro com a chave passada armazenado no Cache.
    */
    std::string getRegistryFromCache(Type regType, std::string_view regKey) const;

    /**
       \brief Retorna verdadeiro se não há registro com a chave indicada no Cache.
    */
    bool hasRegistryFromCache(Type regType, std::string_view regKey) const;

    /**
       \brief Cache que possui todos os registros de usuário.

       O uso de std::less<> na definição da relação permite "transparent comparison" nas buscas, de modo que seja
       possível passar valor "equivalente" às chaves, mas de tipos diferentes.
    */
    std::map<std::string, std::string, std::less<>> m_userRegistryCache;

    /**
       \brief Cache que possui todos os registros do sistema.

       O uso de std::less<> na definição da relação permite "transparent comparison" nas buscas, de modo que seja
       possível passar valor "equivalente" às chaves, mas de tipos diferentes.
    */
    std::map<std::string, std::string, std::less<>> m_systemRegistryCache;
};

/**
   Gerenciador de configurações do registro.

   \attention É definido usando herança, e não \c typedef, para que possa ser usado fora dos limites dessa biblioteca.
*/
class DFF_PUBLIC RegistryManager {
public:
    // A reimplementação de Instance() é necessária para que várias factories não sejam criadas nas bordas das DLLs.
    static Registry& Instance();
};

std::ostream& operator<<(std::ostream& os, Registry::Type);

} // namespace DFF

#endif
