/**
   \file Registry.cpp

   \brief Conjunto de funções para acessar os registros.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado

   \author Francisco de Paula Dias Neto
*/

#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <array>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#ifndef _DFF_ON_WINDOWS_
#include <stdlib.h>
#endif

#include "ExceptionUtils.h"
#include "FilesystemUtils.h"
#include "Registry.h"
#include "SimpleParser.h"
#include "StringUtils.h"

// Necessário para inclusão de getenv_s
#ifdef __STDC_LIB_EXT1__
#define __STDC_WANT_LIB_EXT1__ 1
#elif defined(_DFF_ON_LINUX_)
#define _GETENV_S_UNAVAILABLE_
#endif

#define REG_CONFIG_FILE "dinamica_ego_8.conf"

#define REG_ALTERNATE_CONFIG_FILE "dinamica_ego_8_system.conf"

namespace DFF {

namespace {

#ifdef _DFF_ON_WINDOWS_
    typedef std::wstring EnvString;
    typedef wchar_t EnvChar;
#define GETENV_S(X, Y, Z, W) (::_wgetenv_s((X), (Y), (Z), (W)))
#else
    typedef std::string EnvString;
    typedef char EnvChar;
#define GETENV_S(X, Y, Z, W) (::getenv_s((X), (Y), (Z), (W)))
#endif

    /**
       \brief Faz o parsing do arquivo de configuração no formato: chave1 = "valor1" chave2 = "valor2".

       O uso de std::less<> na definição da relação retornada permite "transparent comparison" nas buscas, de modo que
       seja possível passar valor "equivalente" às chaves, mas de tipos diferentes.
    */
    std::map<std::string, std::string, std::less<>> parseConfigurationFile(const fs::path& dinamicaEgoConfPath);

#ifdef _DFF_ON_WINDOWS_
    const std::string WINDOWS_REGISTRY_KEY = "SOFTWARE\\CSR\\Dinamica EGO 8";

    /**
       \brief Retorna o tipo específico do registro na plataforma, dependendo do valor passado como regType.
    */
    HKEY getRegistry(Registry::Type regType);

#else
    fs::path getSystemConfigurationFilePath();

    fs::path getUserConfigurationFilePath();

    fs::path getRegistry(Registry::Type regType);
#endif

    /**
       \brief Retorna verdadeiro caso haja o registro com a chave passada no tipo requerido.
    */
    bool hasRegistry(std::string_view key, const Registry::Type& regType);

    /**
       \brief Retorna o valor da chave passada no tipo de registro requerido.

       Caso não haja o valor no registro (que possa ser acessado), uma exceção será lançada.
    */
    std::string getRegistryValue(std::string_view key, const Registry::Type& regType);

    /**
       \brief Recupera uma variável de ambiente para ser usada no registro.

       Essa função é embrulhada para que a exceção correta seja retornada.
    */
    std::string getEnvironmentVariableValue(std::string_view key);

} // namespace

std::string Registry::getProperty(std::string_view key, Registry::Type regType, bool ignoreCache)
{
    if (regType == Type::ENVIRONMENT) {
        // Caso o usuário tenha mudado as configurações locais da sessão, a prioridade é considerar a nova configuração
        // ao invés de uma variável de ambiente externa.
        if (!ignoreCache && hasRegistryFromCache(Registry::Type::USER, key))
            return getRegistryFromCache(Registry::Type::USER, key);
        else
            return getEnvironmentVariableValue(key);

    } else if (!ignoreCache && hasRegistryFromCache(regType, key))
        return getRegistryFromCache(regType, key);

    else {
        const std::string value(getRegistryValue(key, regType));
        setRegistryInCache(regType, key, value);

        return value;
    }
}

bool Registry::getPropertyIfExists(std::string_view key, std::string& value, Type regType, bool ignoreCache)
{
    if (hasProperty(key, regType, ignoreCache)) {
        value = getProperty(key, regType, ignoreCache);
        return true;

    } else {
        return false;
    }
}

std::string Registry::getAutoProperty(std::string_view key, bool ignoreCache)
{
    static const std::array<Type, 3> registryTypes { Type::ENVIRONMENT, Type::USER, Type::SYSTEM };

    std::string property;
    for (const Type& registryType : registryTypes) {
        if (hasProperty(key, registryType, ignoreCache)) {
            property = getProperty(key, registryType, ignoreCache);
            break;
        }
    }

    if (property.empty()) {
        throwException_(std::runtime_error,
            "Failed to retrieve key \"" << key << "\". Make sure the property is installed properly in your system.");
    }

    return property;
}

bool Registry::getAutoPropertyIfExists(std::string_view key, std::string& value, bool ignoreCache)
{
    static const std::array<Type, 3> registryTypes { Type::ENVIRONMENT, Type::USER, Type::SYSTEM };

    for (const Type& registryType : registryTypes) {
        if (hasProperty(key, registryType, ignoreCache)) {
            value = getProperty(key, registryType, ignoreCache);
            return true;
        }
    }

    return false;
}

bool Registry::hasProperty(std::string_view key, Type regType, bool ignoreCache) const
{
    if (regType == Type::ENVIRONMENT) {
        std::string envVarValue = getEnvironmentVariableValue(key);

        return (envVarValue.empty() == false);

    } else {
        const bool hasPropertyInCache = !ignoreCache && hasRegistryFromCache(regType, key);

        return hasPropertyInCache || hasRegistry(key, regType);
    }
}

bool Registry::hasAutoProperty(std::string_view key, bool ignoreCache) const
{
    static const std::array<Type, 3> registryTypes { Type::ENVIRONMENT, Type::USER, Type::SYSTEM };

    // Essa função não realiza travamento pois apenas chama hasProperty() (que trava internamente) e em seguida retorna
    // imediatamente.

    for (const Type& registryType : registryTypes) {
        if (hasProperty(key, registryType, ignoreCache)) {
            return true;
        }
    }

    return false;
}

std::ostream& operator<<(std::ostream& os, Registry::Type regType)
{
    switch (regType) {
    case Registry::Type::ENVIRONMENT:
        os << "Environment";
        break;

    case Registry::Type::SYSTEM:
        os << "System";
        break;

    case Registry::Type::USER:
        os << "User";
        break;

    default:
        break;
    }

    return os;
}

const std::map<std::string, std::string, std::less<>>& Registry::getRegistryCacheByType(Registry::Type regType) const
{
    switch (regType) {
    case Registry::Type::SYSTEM:
        return m_systemRegistryCache;
        break;

    case Registry::Type::USER:
        return m_userRegistryCache;
        break;

    default:
        break;
    }

    // Não pode ser alcançado.
    return m_userRegistryCache;
}

std::map<std::string, std::string, std::less<>>& Registry::getRegistryCacheByType(Registry::Type regType)
{
    switch (regType) {
    case Registry::Type::SYSTEM:
        return m_systemRegistryCache;
        break;

    case Registry::Type::USER:
        return m_userRegistryCache;
        break;

    default:
        break;
    }

    // Não pode ser alcançado.
    return m_userRegistryCache;
}

void Registry::setRegistryInCache(Registry::Type regType, std::string_view key, std::string_view value)
{
    getRegistryCacheByType(regType).insert_or_assign(std::string(key), value);
}

void Registry::setRegistriesInCache(
    Registry::Type regType, const std::map<std::string, std::string, std::less<>>& registries)
{
    std::map<std::string, std::string, std::less<>>& registryCache = getRegistryCacheByType(regType);

    for (const auto& registry : registries)
        registryCache[registry.first] = registry.second;
}

std::string Registry::getRegistryFromCache(Registry::Type regType, std::string_view key) const
{
    auto& registry = getRegistryCacheByType(regType);
    auto it = registry.find(key);

    if (it == registry.end()) {
        throwException_(std::runtime_error, "Registry key \"" << key << "\" not found in " << regType << " registry.");
    }

    return it->second;
}

bool Registry::hasRegistryFromCache(Registry::Type regType, std::string_view key) const
{
    // Essa função por definição não deve disparar exceções, mas não pode ser marcado como 'noexcept' devido à asserção
    // na chamada getRegistryCacheByType.

    std::map<std::string, std::string, std::less<>> registryCache = getRegistryCacheByType(regType);

    return registryCache.find(key) != registryCache.end();
}

Registry& RegistryManager::Instance()
{
    static Registry registry;

    return registry;
}

namespace {

    std::map<std::string, std::string, std::less<>> parseConfigurationFile(const fs::path& dinamicaEgoConfPath)
    {
        // Abre o arquivo e faz o parsing da chave desejada.
        std::string dinamicaEgoConf;
        try {
            FilesystemUtils::readFile(dinamicaEgoConf, dinamicaEgoConfPath);

            std::map<std::string, std::string, std::less<>> readConfigurations;

            namespace sp = SimpleParser;
            sp::Context input(dinamicaEgoConf);

            while (!input.parse<sp::word>(sp::RuleAction::LOOK_AHEAD).contents.empty()) {
                const std::string key = input.parse<sp::word>().contents;

                input.parse<sp::char_>('=');

                const std::string value = input.parse<sp::quotedWord>().contents;
                readConfigurations[key] = value;
            }

            return readConfigurations;

        } catch (std::exception& e) {
            throwException_(std::runtime_error, e.what());
        }
    }

#ifdef _DFF_ON_WINDOWS_
    HKEY getRegistry(Registry::Type regType)
    {
        switch (regType) {
        case Registry::Type::SYSTEM:
            return HKEY_LOCAL_MACHINE;
            break;

        case Registry::Type::USER:
            return HKEY_CURRENT_USER;
            break;

        default:
            break;
        }

        // Não pode ser alcançado.
        return HKEY_LOCAL_MACHINE;
    }

#else
    fs::path getSystemConfigurationFilePath()
    {
        fs::path systemEgoConf = fs::u8path("/etc") / fs::u8path(REG_CONFIG_FILE);
        if (!FilesystemUtils::filenameExists(systemEgoConf)) {
            fs::path homeDir = getenv("HOME");
            if (homeDir.empty())
                throwException_(std::runtime_error, "$HOME not found.");

            fs::path userSystemEgoConf = homeDir / fs::u8path("." REG_ALTERNATE_CONFIG_FILE);

            // Cria o arquivo se ele não existir.
            if (!FilesystemUtils::filenameExists(userSystemEgoConf)) {
                std::ofstream touchedFile(userSystemEgoConf, std::ios_base::out);
                touchedFile.close();
            }

            if (!FilesystemUtils::filenameExists(userSystemEgoConf))
                throwException_(std::runtime_error, "System configuration file \"" << FilesystemUtils::genericString(
                                                        userSystemEgoConf) << "\" does not exist.");

            return userSystemEgoConf;

        } else
            return systemEgoConf;
    }

    fs::path getUserConfigurationFilePath()
    {
        fs::path homeDir = fs::u8path(getenv("HOME"));
        if (homeDir.empty())
            throwException_(std::runtime_error, "$HOME not found.");

        // Lê o arquivo de configurações local.
        fs::path localConf = homeDir / fs::u8path("." REG_CONFIG_FILE);

        // Cria o arquivo se ele não existir.
        if (!FilesystemUtils::filenameExists(localConf)) {
            std::ofstream touchedFile(localConf, std::ios_base::out);
            touchedFile.close();
        }

        if (!FilesystemUtils::filenameExists(localConf))
            throwException_(std::runtime_error,
                "User configuration file \"" << FilesystemUtils::genericString(localConf) << "\" does not exist.");

        return localConf;
    }

    fs::path getRegistry(Registry::Type regType)
    {
        switch (regType) {
        case Registry::Type::SYSTEM:
            return getSystemConfigurationFilePath();

        case Registry::Type::USER:
            return getUserConfigurationFilePath();

        default:
            // Não pode ser alcançado.
            return fs::path();
        }
    }

#endif

    bool hasRegistry(std::string_view key, const Registry::Type& regType)
    {
        // O configPath é usado apenas se estiver na versão portável ou se for no linux, pois em ambos os registros são
        // armazenados em arquivos de configuração.
        fs::path configPath;
#ifdef _DFF_ON_WINDOWS_
        HKEY dinamicaKey;
        if (RegOpenKeyEx(getRegistry(regType), WINDOWS_REGISTRY_KEY.data(), 0, KEY_READ, &dinamicaKey)
            != ERROR_SUCCESS) {

            return false;
        }

        const std::size_t maxBuffSize = 1024;
        char tempBuffer[maxBuffSize] = { 0 };
        DWORD type = REG_SZ;
        DWORD maxSize = static_cast<DWORD>(maxBuffSize);

        if (RegQueryValueEx(dinamicaKey, key.data(), NULL, &type, (LPBYTE)&tempBuffer, &maxSize) == ERROR_SUCCESS) {

            RegCloseKey(dinamicaKey);
            tempBuffer[maxBuffSize - 1] = '\0';
            const std::string buffString(tempBuffer);

            return buffString.empty() == false;

        } else {
            RegCloseKey(dinamicaKey);
            return false;
        }

#else
        configPath = getRegistry(regType);
#endif

        std::map<std::string, std::string, std::less<>> parsedConfiguration = parseConfigurationFile(configPath);

        return parsedConfiguration.find(key) != parsedConfiguration.end();
    }

    std::string getRegistryValue(std::string_view key, const Registry::Type& regType)
    {
        // O configPath é usado apenas se estiver na versão portável ou se for no linux, pois em ambos os registros são
        // armazenados em arquivos de configuração.
        fs::path configPath;

#ifdef _DFF_ON_WINDOWS_
        HKEY dinamicaKey;
        if (RegOpenKeyEx(getRegistry(regType), WINDOWS_REGISTRY_KEY.data(), 0, KEY_READ, &dinamicaKey)
            != ERROR_SUCCESS) {

            return std::string();
        }

        const std::size_t maxBuffSize = 1024;
        char tempBuffer[maxBuffSize] = { 0 };
        DWORD type = REG_SZ;
        DWORD maxSize = static_cast<DWORD>(maxBuffSize);

        if (RegQueryValueEx(dinamicaKey, key.data(), NULL, &type, (LPBYTE)&tempBuffer, &maxSize) != ERROR_SUCCESS) {
            RegCloseKey(dinamicaKey);
            throwException_(
                std::runtime_error, "Failed to retrieve key \""
                                        << key << "\" from " << regType
                                        << " registry. Make sure Dinamica EGO is installed properly in your system.");

        } else {
            RegCloseKey(dinamicaKey);
            // Garante strings terminadas com 0.
            tempBuffer[maxBuffSize - 1] = '\0';
            return std::string(tempBuffer);
        }
#else
        configPath = getRegistry(regType);
#endif

        std::map<std::string, std::string, std::less<>> parsedConfiguration = parseConfigurationFile(configPath);
        auto it = parsedConfiguration.find(key);

        return it != parsedConfiguration.end() ? it->second : std::string();
    }

#if defined(_GETENV_S_UNAVAILABLE_) && !defined(_DFF_ON_WINDOWS_)

    std::string getEnvironmentVariableValue(std::string_view variableName)
    {
        std::string returnValue;

        char* tmpValue = ::getenv(variableName.data());
        if (tmpValue != nullptr)
            returnValue = EnvString(tmpValue);

        return returnValue;
    }

#else

    std::string getEnvironmentVariableValue(std::string_view tmpVariableName)
    {
#ifdef _DFF_ON_WINDOWS_
        const EnvString variableName(DFF::StringUtils::fromUTF8(tmpVariableName));
#else
        const EnvString variableName(tmpVariableName);
#endif

        EnvString returnValue;

        std::size_t pathLen = 0;

        if (GETENV_S(&pathLen, NULL, 0, variableName.c_str()) == 0 && pathLen != 0) {

            // Aloca o espaço necessário e lê a variável.
            EnvChar* pathValue = new EnvChar[pathLen];
            std::memset(pathValue, 0, pathLen * sizeof(EnvChar));

            if (GETENV_S(&pathLen, pathValue, pathLen, variableName.c_str()) == 0 && pathLen != 0) {

                returnValue = EnvString(pathValue);
            }

            // Apaga o espaço alocado.
            delete[] pathValue;
        }

#ifdef _DFF_ON_WINDOWS_
        return DFF::StringUtils::toUTF8(returnValue);
#else
        return returnValue;
#endif
    }

#endif

} // namespace

} // namespace DFF
