/**
   \file Config.h

   \brief Configura��es b�sicas de compila��o.

   \attention � IMPORTANTE QUE ESSE SEJA O PRIMEIRO ARQUIVO INCLU�DO.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira
*/

#ifndef _BASE_CONFIG_H_
#define _BASE_CONFIG_H_

#if defined(__linux) || defined(__linux__) || defined(__gnu_linux__) || defined(linux)
#define _DFF_ON_LINUX_
#else
#define _DFF_ON_WINDOWS_
#endif

/**
   \brief Definições usadas pelo Windows.

   É feita ainda a definição do Endian da arquitetura.
 */
#ifdef _DFF_ON_WINDOWS_
#define WIN32_LEAN_AND_MEAN
#include <new.h>
#include <windows.h>
#endif

#define DFF_PUBLIC

#ifdef _DFF_ON_WINDOWS_
#define FILE_STRING std::wstring
#else
#define FILE_STRING std::string
#endif

#endif
