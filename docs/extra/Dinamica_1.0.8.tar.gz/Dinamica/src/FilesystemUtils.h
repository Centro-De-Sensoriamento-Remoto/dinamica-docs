/**
   \file FilesystemUtils.h

   \brief Definição de utilitários para a manipulação de arquivos.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Hermann Oliveira Rodrigues

   \author Gustavo Coutinho Cerqueira

   \author Bruno Morais Ferreira

   \author Francisco de Paula Dias Neto
*/

#ifndef _DFF_FILESYSTEM_UTILS_H_
#define _DFF_FILESYSTEM_UTILS_H_

#include "Config.h"

#include <filesystem>
#include <string>

namespace fs = std::filesystem;

namespace DFF {

/**
   \brief Utilitários usados na manipulação de arquivos.
*/
class DFF_PUBLIC FilesystemUtils {
public:
    //////////////////////////////////////////////////////////////////////////////
    // Manipulação de extensões de arquivos.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Recupera a extensão do nome de arquivo dado.

       \param filename Nome de arquivo de onde a extensão sera obtida.

       \return Extensão do arquivo, caso o arquivo possua extensão, ou a string vazia, caso contrário. A extensão
       retornada inclui o caractere "." e tem todos os seus caracteres convertidos para minúsculas.
    */
    static std::string getFilenameExtension(const fs::path& filename);

    /**
       \brief Retorna nome de arquivo usando outra extensão.

       Essa versão é equivalente a versão definida como fs::change_extension mas, ao contrário dessa, funciona
       corretamente quando os nomes de arquivo possuem espaços.

       \param filename Nome de arquivo.

       \param extension Nova extensão do nome do arquivo. O "." deve ser fornecido como parte da extensão.
    */
    static fs::path changeFilenameExtension(const fs::path& filename, const std::string& extension);

    //////////////////////////////////////////////////////////////////////////////
    // Leitura de arquivos.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Retorna o conteúdo do arquivo UTF-8.

       \param output Referência para a string onde o resultado da leitura do arquivo será retornada.

       \param filename Nome de arquivo que será lido.

       \exception UnableToAccessFileException Caso não seja possível ler o conteúdo do arquivo.
    */
    static void readFile(std::string& output, const fs::path& filename);

    //////////////////////////////////////////////////////////////////////////////
    // Gravação de texto em arquivos.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Salva o conteúdo no arquivo UTF-8.

       \param input std::istream contendo o texto que será salvo no arquivo. Essa stream será gravada da posição atual
       até o seu fim no arquivo (a stream será modificada para leitura do conteúdo). Após a gravação, ela será ajustada
       para retorna à posição inicial.

       \param filename Nome de arquivo onde se fará a gravação.

       \exception Exception Caso não seja possível salvar o conteúdo do arquivo.
    */
    static void writeFile(std::istream& input, const fs::path& filename);

    /**
       \brief Salva o conteúdo no arquivo UTF-8.

       \param input O texto que será salvo no arquivo.

       \param filename Nome de arquivo onde se fará a gravação.

       \exception Exception Caso não seja possível salvar o conteúdo do arquivo.
    */
    static void writeFile(const std::string& input, const fs::path& filename);

    //////////////////////////////////////////////////////////////////////////////
    // Manipulação de caminhos de arquivos.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Retorna a representação do nome de arquivo relativa ao diretório corrente.

       \param filename Nome de arquivo.
    */
    static fs::path getRelativeFilename(const fs::path& filename);

    /**
       \brief Retorna a representação do nome de arquivo relativa ao diretório dado.

       \param directory Nome do diretório.

       \param filename Nome de arquivo.
    */
    static fs::path getRelativeFilename(const fs::path& directory, const fs::path& filename);

    /**
       \brief Completa um nome relativo de arquivo com base no diretório dado.

       \param directory Nome do diretório.

       \param filename Nome de arquivo.

       \throws IllegalFileException Caso filename não seja relativo e directory completo.
    */
    static fs::path getCompleteFilename(const fs::path& directory, const fs::path& filename);

    /**
       \brief Retorna nome de arquivo sufixado com um número e uma extensão.

       \param prefix Prefixo do nome do arquivo.

       \param suffixSize Número de dígitos que serão usados para representar o sufixo do nome de arquivo. Caso o sufixo
       seja maior que esse número de dígitos, será usado o próprio sufixo sem modificações.

       \param suffix Sufixo do nome de arquivo.

       \param extension Extensão do nome do arquivo. O "." deve ser fornecido como parte da extensão.

       \exception fs::filesystem_error Caso o nome de arquivo resultante não seja sintaticamente válido.
    */
    static fs::path generateFilename(
        const std::string& prefix, int suffixSize, int suffix, const std::string& extension);

    //////////////////////////////////////////////////////////////////////////////
    // Teste de arquivo.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Verifica se o arquivo existe e pode ser aberto para leitura.

       O arquivo dado é realmente aberto para leitura durante a verificação.

       \param filename Nome de arquivo.
    */
    static bool canReadFilename(const fs::path& filename);

    /**
       \brief Verifica se o arquivo existe e pode ser aberto para escrita.

       O arquivo dado é realmente aberto para escrita durante a verificação.

       \param filename Nome de arquivo.
    */
    static bool canWriteFilename(const fs::path& filename);

    /**
       \brief Verifica se o arquivo existe.

       \param filename Nome de arquivo.
    */
    static bool filenameExists(const fs::path& filename);

    //////////////////////////////////////////////////////////////////////////////
    // Manipulação de arquivos temporarios.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Retorna um arquivo temporário usando a extensão dada.

       \param extension Extensão do nome do arquivo. O "." deve ser fornecido como parte da extensão.

       \exception Exception Caso não seja possível criar o arquivo temporário.
    */
    static fs::path createTemporaryFile(const std::string& extension);

    /**
       \brief Retorna nome de arquivo temporário usando a extensão dada.

       \param extension Extensão do nome do arquivo. O "." deve ser fornecido como parte da extensão.

       \exception Exception Caso não seja possível criar o nome para o arquivo temporário.
    */
    static fs::path generateTemporaryFilename(const std::string& extension);

    /**
       \brief Retorna um nome de arquivo no diretório temporário padrão do sistema.

       Essa função retorna um caminho de arquivo válido no diretório temporário sem que sua definição use bibliotecas do
       boost, para maior portabilidade.

       \param baseName Nome de base do arquivo a ter o diretório concatenado.

       \exception Exception Caso não seja concatenar o nome de arquivo ao caminho temporário do sistema.
    */
    static std::string getCompleteTemporaryPath(const std::string& baseName);

    //////////////////////////////////////////////////////////////////////////////
    // Manipulação de arquivos.
    //////////////////////////////////////////////////////////////////////////////

    /**
       \brief Remove o arquivo ou diretório.

       Caso o nome de arquivo corresponda a diretório, todo o seu conteúdo será removido.

       Caso o arquivo ou diretório não exista, essa função não tem efeito.

       \param filename Nome de arquivo ou diretório que será removido.

       \exception Exception Caso não seja possível remover o arquivo ou diretório.
    */
    static void removeFileOrFolder(const fs::path& filename);

    /**
       \brief Remove o caminho passado caso seja possível.

       Caso não seja possível remover o arquivo, uma mensagem será escrita no log indicando o motivo.

       \param path Caminho de arquivo ou diretório que será removido.
    */
    static void removeFileOrFolderIfPossible(const fs::path& path);

    /**
       \brief Retorna a representação fantasia correspondente a combinação do diretório de trabalho e caminho de arquivo
       especificado.
    */
    static std::string getFancyFilenameString(const fs::path& workdir, const fs::path& filename);

    /**
       \brief Retorna a string representando o caminho de arquivo correspondente a path::string().

       \remarks Note que path::string() não deve ser usado diretamente pois é possível que o caminho de arquivo dado não
       possua representação ASCII.

       \return String representando o caminho de arquivo. A string retornada sempre usa a representação UTF-8.
    */
    static std::string string(const fs::path& path);

    /**
       \brief Retorna a string representando o caminho de arquivo correspondente a path::generic_string().

       \remarks Note que path::generic_string() não deve ser usado diretamente pois é possível que o caminho de arquivo
       dado não possua representação ASCII.

       \return String representando o caminho de arquivo. A string retornada sempre usa a representação UTF-8.
    */
    static std::string genericString(const fs::path& path);
};

class FileHandle {
public:
    FileHandle(const fs::path& filename, const FILE_STRING& mode);

    ~FileHandle();

    bool is_open() const { return m_isOpen; }

    const fs::path& filename() const { return m_filename; }

    long tellg() const;

    int seek(long pos);

    std::size_t read(char* result, size_t numBytes);

    int getChar();

    std::size_t write(const char* data, size_t numBytes);

    void close(bool noExcept = false);

    int flush();

    friend std::ostream& operator<<(std::ostream& lhs, const FileHandle& rhs)
    {
        return lhs << DFF::FilesystemUtils::genericString(rhs.filename());
    }

private:
    FILE* m_handle;

    bool m_isOpen;

    fs::path m_filename;
};

} // namespace DFF

#endif
