/**
   \file FilenameLock.cpp

   \brief Definição de uma trava para acesso exclusivo à arquivos.

   Copyright&copy; 1998-2022 Centro de Sensoriamento Remoto / Universidade Federal de Minas Gerais - Brazil.  All Rights
   Reserved.

   \author Romulo Fernandes Machado
*/

#include "Config.h"
#define _DFF_CPP_LIBRARY_ BaseLib

#include <chrono>
#include <filesystem>
#include <string>
#include <thread>

#ifdef _DFF_ON_WINDOWS_
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
#endif

#include "ExceptionUtils.h"
#include "FilenameLock.h"
#include "FilesystemUtils.h"

// Número máximo de tentativas de destravamento para evitar loops infinitos.
#define MAX_UNLOCK_ATTEMPTS 30

// Número de bytes para travar no arquivo.
#define LOCK_NUM_BYTES sizeof(int)

namespace DFF {

#ifdef _WINDOWS_

namespace {

    /**
       \brief Retorna uma estrutura 'OVERLAPPED' para travar os primeiros 4 bytes do arquivo.
    */
    OVERLAPPED getOverlapped()
    {
        OVERLAPPED overlapped;
        memset(&overlapped, 0, sizeof(OVERLAPPED));

        overlapped.Internal = LOCK_NUM_BYTES;
        return overlapped;
    }

} // namespace

FilenameLock::FilenameLock(const fs::path& filename, LockBehavior lockBehavior, bool preventSharing)
{
    m_handle = CreateFileW(filename.wstring().c_str(), GENERIC_READ | GENERIC_WRITE,
        preventSharing ? 0 : (FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE), NULL, OPEN_ALWAYS,
        FILE_ATTRIBUTE_NORMAL, NULL);

    if (m_handle == INVALID_HANDLE_VALUE)
        throwException_(std::runtime_error,
            "Failed to lock \"" << DFF::FilesystemUtils::genericString(filename) << "\", access failed.");

    const DWORD lockFlags =
        LOCKFILE_EXCLUSIVE_LOCK | (lockBehavior == LockBehavior::THROW_ON_BUSY ? LOCKFILE_FAIL_IMMEDIATELY : 0);

    OVERLAPPED overlapped = getOverlapped();
    BOOL lockSucceed = LockFileEx(m_handle, lockFlags, 0, LOCK_NUM_BYTES, 0, &overlapped);

    if (lockSucceed == FALSE) {
        // Descarta o handle alocado.
        CloseHandle(m_handle);

        throwException_(
            std::runtime_error, "Failed to lock \"" << DFF::FilesystemUtils::genericString(filename) << "\".");
    }
}

FilenameLock::~FilenameLock()
{
    if (m_handle != INVALID_HANDLE_VALUE)
        release();
}

void FilenameLock::release() noexcept
{
    OVERLAPPED overlapped = getOverlapped();
    for (std::size_t numTries = 0; numTries < MAX_UNLOCK_ATTEMPTS; ++numTries) {

        if (UnlockFileEx(m_handle, 0, LOCK_NUM_BYTES, 0, &overlapped) != 0)
            break;

        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }

    CloseHandle(m_handle);
    m_handle = INVALID_HANDLE_VALUE;
}

#else

FilenameLock::FilenameLock(const fs::path& filename, LockBehavior lockBehavior, bool preventSharing)
    : m_handle(-1)
{
    // O modo 0777 (octal, diferente de 777) deve ser usado para evitar que o arquivo não possa ser acessado.
    m_handle = open(DFF::FilesystemUtils::genericString(filename).c_str(), O_RDWR | O_CREAT, 0777);

    if (m_handle == -1)
        throwException_(std::runtime_error,
            "Failed to lock \"" << DFF::FilesystemUtils::genericString(filename) << "\", access failed.");

    int lockFD = flock(m_handle, LOCK_EX | (lockBehavior == LockBehavior::THROW_ON_BUSY ? LOCK_NB : 0));

    if (lockFD == -1)
        throwException_(
            std::runtime_error, "Failed to lock \"" << DFF::FilesystemUtils::genericString(filename) << "\".");
}

FilenameLock::~FilenameLock()
{
    if (m_handle != -1)
        release();
}

void FilenameLock::release() noexcept
{
    for (std::size_t numTries = 0; numTries < MAX_UNLOCK_ATTEMPTS; ++numTries) {

        int lockStatus = flock(m_handle, LOCK_UN);
        if (lockStatus == 0)
            break;

        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }

    close(m_handle);
    m_handle = -1;
}

#endif

} // namespace DFF
